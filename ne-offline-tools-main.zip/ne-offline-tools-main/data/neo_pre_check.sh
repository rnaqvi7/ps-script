#!/bin/bash

# This script will check for the prerequesits of each available tool
pass_count=0
total_count=0

function print_pass () {
  echo -e "\e[32mPASSED\e[0m"
}

function print_fail () {
  echo -e "\e[31mFAILED\e[0m"
}

function print_unknown () {
  echo -e "\e[33mUNKNOWN\e[0m"
}

function print_status () {
  if [ "$1" = true ]; then
    print_pass
  elif [ "$1" = false ]; then
    print_fail
  else
    print_unknown
  fi
}

function check_modules () {
    echo "### Checking modules ###"
    ((total_count++))
    overlay=$(lsmod | grep -w overlay)
    br_netfilter=$(lsmod | grep -w br_netfilter)

    if [[ -n $overlay ]]; then
        echo -e "overlay module is \e[32menabled\e[0m"
        overlay_status=true
    else
        echo -e "overlay module is \e[31mnot enabled\e[0m"
        overlay_status=false
    fi

    if [[ -n $br_netfilter ]]; then
        echo -e "br_netfilter module is \e[32menabled\e[0m"
        br_netfilter_status=true
    else
        echo -e "br_netfilter module is \e[31mnot enabled\e[0m"
        br_netfilter_status=false
    fi

    if [[ $overlay_status && $br_netfilter_status == true ]]; then
        module_status=true
        ((pass_count++))
    else
        module_status=false
    fi
    echo "### Check: $(print_status $module_status) ###"
}

function check_sysctl () {
  echo "### Checking sysctl ###"
  ((total_count++))
  declare -A sysctl_checks=(
    ["fs.inotify.max_user_watches"]=1048576
    ["fs.inotify.max_user_instances"]=1024
    ["net.bridge.bridge-nf-call-ip6tables"]=1
    ["net.bridge.bridge-nf-call-iptables"]=1
    ["net.ipv4.ip_forward"]=1
  )

  sysctl_status=true

  for key in "${!sysctl_checks[@]}"; do
    value=$(sysctl -n $key)
    expected_value=${sysctl_checks[$key]}

    if [[ $value -eq $expected_value ]]; then
      echo -e "$key = \e[32m$value\e[0m"
    else
      echo -e "$key = \e[31m$value\e[0m"
      sysctl_status=false
    fi
  done

  if [[ $sysctl_status == true ]]; then
    ((pass_count++))
  fi
  echo "### Check: $(print_status $sysctl_status) ###"
}

function check_swap () {
  echo "### Checking swap ###"
  ((total_count++))
  swap_status=$(swapon -s | wc -l)
  if [[ $swap_status -eq 0 ]]; then
    echo -e "swap is \e[32mnot enabled\e[0m"
    swap_status=true
    ((pass_count++))
  else
    echo -e "swap is \e[31menabled\e[0m"
    swap_status=false
  fi
  echo "### Check: $(print_status $swap_status) ###"
}

function check_runc () {
  echo "### Checking runc ###"
  ((total_count++))
  runc_status=$(which runc)
  if [[ -n $runc_status ]]; then
    echo -e "runc is \e[32minstalled\e[0m"
    runc_status=true
    ((pass_count++))
  else
    echo -e "runc is \e[31mnot installed\e[0m"
    runc_status=false
  fi
  echo "### Check: $(print_status $runc_status) ###"
}

function check_containerd () {
  ((total_count++))
  echo "### Checking containerd ###"
  containerd_status=$(systemctl status containerd)
  if [[ $? -eq 0 ]]; then
    echo -e "containerd is \e[32minstalled and running\e[0m"
    containerd_status=true
    ((pass_count++))
  else
    echo -e "containerd is \e[31mnot installed or not running\e[0m"
    containerd_status=false
  fi
  echo "### Check: $(print_status $containerd_status) ###"
}

function check_cni_plugins () {
  ((total_count++))
  echo "### Checking cni-plugins ###"
  cni_status=$(ls /opt/cni/bin/* 2>/dev/null | wc -l)
  if [[ $cni_status -gt 0 ]]; then
    echo -e "cni-plugins are \e[32minstalled\e[0m"
    cni_status=true
    ((pass_count++))
  else
    echo -e "cni-plugins are \e[31mnot installed\e[0m"
    cni_status=false
  fi
  echo "### Check: $(print_status $cni_status) ###"
}


function check_kube_apps () {
  ((total_count++))
  echo "### Checking Kubernetes tools ###"
  kubeadm_status=$(which kubeadm)
  if [[ -n $kubeadm_status ]]; then
    echo -e "kubeadm is \e[32minstalled\e[0m"
    kubeadm_status=true
  else
    echo -e "kubeadm is \e[31mnot installed\e[0m"
    kubeadm_status=false
  fi
  kubectl_status=$(which kubectl)
  if [[ -n $kubectl_status ]]; then
    echo -e "kubectl is \e[32minstalled\e[0m"
    kubectl_status=true
  else
    echo -e "kubectl is \e[31mnot installed\e[0m"
    kubectl_status=false
  fi
  kubelet_status=$(systemctl status kubelet 2> /dev/null)
  if [[ $? -eq 0 ]]; then
    echo -e "kubelet is \e[32minstalled and running\e[0m"
    kubelet_status=true
  else
    echo -e "kubelet is \e[31mnot installed or not running\e[0m"
    kubelet_status=false
  fi
  if [[ $kubeadm_status && $kubectl_status && $kubelet_status == 'true' ]]; then
    kubeapps_status=true
    ((pass_count++))
  else
    kubeapps_status=false
  fi
  echo "### Check: $(print_status $kubeapps_status) ###"
}

function check_kubernetes () {
  echo "### Checking Kubernetes ###"
  ((total_count++))
  k8s_status=$(kubectl get nodes 2> /dev/null| grep Ready | awk '{print $2}')
  if [[ $k8s_status == Ready ]]; then
    echo -e "Kubernetes is \e[32mInstalled and Ready\e[0m"
    k8s_status=true
    ((pass_count++))
  else
    echo -e "Kubernetes is \e[31mnot reachable or not Ready\e[0m"
    k8s_status=false
  fi
  echo "### Check: $(print_status $k8s_status) ###"
}

function check_calico () {
  echo "### Checking Calico ###"
  ((total_count++))
  calico_pod_count=$(kubectl get pods -A 2> /dev/null | grep calico | wc -l)
  calico_pod_check=$(kubectl get pods -A --no-headers 2> /dev/null | grep calico | awk '{print $3}' | awk -F'/' '{if ($1 != $2) print $0}' |wc -l)
  if [[ $calico_pod_count != 2 ]]; then
    echo -e "Calico pods \e[31mnot Found\e[0m"
    calico_status=false
  elif [[ $calico_pod_check != 0 ]]; then
    echo -e "Calico pods \e[31mnot Running\e[0m"
    calico_status=false
  else
    echo -e "Calico is \e[32mInstalled and Healthy\e[0m"
    calico_status=true
    ((pass_count++))
  fi
  echo "### Check: $(print_status $calico_status) ###"
}

function check_longhorn () {
  echo "### Checking Longhorn ###"
  ((total_count++))
  longhorn_ns=$(kubectl get ns longhorn-system 2> /dev/null)
  longhorn_pod_check=$(kubectl get pods -n longhorn-system --no-headers 2> /dev/null| awk '{print $2}' | awk -F'/' '{if ($1 != $2) print $0}' |wc -l)
  if [[ ! $longhorn_ns ]]; then
    echo -e "Longhorn is \e[31mnot Installed\e[0m"
    longhorn_status=false
  elif [[ $longhorn_pod_check != 0 ]]; then
    echo -e "Longhorn pods \e[31mnot Running\e[0m"
    longhorn_status=false
  else
    echo -e "Longhorn is \e[32mInstalled and Healthy\e[0m"
    longhorn_status=true
    ((pass_count++))
  fi
  echo "### Check: $(print_status $longhorn_status) ###"
}

function check_metallb () {
  echo "### Checking MetalLB ###"
  ((total_count++))
  metallb_ns=$(kubectl get ns metallb-system 2> /dev/null)
  metallb_pod_check=$(kubectl get pods -n metallb-system --no-headers 2> /dev/null| awk '{print $2}' | awk -F'/' '{if ($1 != $2) print $0}' |wc -l)
  metallb_IPAddressPool_check=$(kubectl -n metallb-system get IPAddressPool --no-headers 2> /dev/null| awk '{print $1}')
  if [[ ! $metallb_ns ]]; then
    echo -e "MetalLB is \e[31mnot Installed\e[0m"
    metallb_status=false
  elif [[ $metallb_pod_check != 0 ]]; then
    echo -e "MetalLB pods \e[31mnot Running\e[0m"
    metallb_status=false
  elif  [[ $metallb_IPAddressPool_check != 'default' ]]; then
    echo -e "MetalLB is \e[31mmissing IPAddressPool\e[0m"
    metallb_status=false
  else
    echo -e "MetalLB is \e[32mInstalled and Healthy\e[0m"
    metallb_status=true
    ((pass_count++))
  fi
  echo "### Check: $(print_status $metallb_status) ###"
}

function check_scheduleable_storage() {
  echo "### Checking scheduleable storage ###"
  ((total_count++))
  local RESERVE=$(kubectl get nodes.longhorn.io -o json -A | jq -r '.items[] | .metadata.name as $node | .spec.disks | to_entries[] | .value.storageReserved')
  local AVAILABLE=$(kubectl get nodes.longhorn.io -o json -A | jq -r '.items[] | .metadata.name as $node | .status.diskStatus | to_entries[] | .value.storageAvailable')
  local SCHEDULEABLE_STORAGE=$(echo "scale=2; ($AVAILABLE - $RESERVE) / 1024 / 1024 / 1024" | bc)
  # Check if the size is 347 GiB or greater
  if (( $(echo "$SCHEDULEABLE_STORAGE >= 347" | bc -l) )); then
      echo -e "Found \e[32m$SCHEDULEABLE_STORAGE GiB\e[0m scheduleable storage, which is 347 GiB or greater."
      storage_status=true
      ((pass_count++))
  else
     echo -e "The scheduleable storage is \e[31m$SCHEDULEABLE_STORAGE GiB\e[0m, which is less than 347 GiB."
     storage_status=false
  fi
  echo "### Check: $(print_status $storage_status) ###"
}

function check_memory_size() {
  echo "### Checking Memory Size ###"
  ((total_count++))
  memory_size=$(free -m | awk '/Mem:/ {print $2}')
  required_memory=22000
  if [[ $EO_VERSION == "3.2" ]]; then
    required_memory=32000
  fi
  if (( $(echo "$memory_size >= $required_memory" | bc -l) )); then
      echo -e "The memory size is \e[32m$memory_size MB\e[0m, which is $required_memory MB or greater."
      memory_size_status=true
      ((pass_count++))
  else
     echo -e "The memory size is \e[31m$memory_size MB\e[0m, which is less than $required_memory MB."
     memory_size_status=false
  fi
  echo "### Check: $(print_status $memory_size_status) ###"
}

function check_cpu_count() {
  echo "### Checking CPU Count ###"
  ((total_count++))
  cpu_count=$(nproc)
  required_cpu=9
  if [[ $EO_VERSION == "3.2" ]]; then
    required_cpu=16
  fi
  if (( $(echo "$cpu_count >= $required_cpu" | bc -l) )); then
      echo -e "The CPU count is \e[32m$cpu_count\e[0m, which is $required_cpu or greater."
      cpu_count_status=true
      ((pass_count++))
  else
     echo -e "The CPU count is \e[31m$cpu_count\e[0m, which is less than $required_cpu."
     cpu_count_status=false
  fi
  echo "### Check: $(print_status $cpu_count_status) ###"
}

function check_helm () {
  echo "### Checking Helm ###"
  ((total_count++))
  helm_install_check=$(helm version 2> /dev/null| grep -o $HELM_VERSION)
  if [[ ! $helm_install_check ]]; then
    echo -e "Helm is \e[31mnot Installed\e[0m"
    helm_status=false
  elif [[ $helm_install_check != $HELM_VERSION ]]; then
    echo -e "Helm version \e[31mismatch $HELM_VERSION\e[0m"
    helm_status=false
  else
    echo -e "Helm is \e[32mInstalled\e[0m"
    helm_status=true
    ((pass_count++))
  fi
  echo "### Check: $(print_status $helm_status) ###"
}

function check_docker () {
  echo "### Checking Docker ###"
  ((total_count++))
  docker_status=$(systemctl status docker 2> /dev/null)
  if [[ $? -eq 0 ]]; then
    echo -e "Docker is \e[32minstalled and running\e[0m"
    docker_status=true
    ((pass_count++))
  else
    echo -e "Docker is \e[31mnot installed or not running\e[0m"
    docker_status=false
  fi
  echo "### Check: $(print_status $docker_status) ###"
}

function check_unzip () {
  echo "### Checking unzip ###"
  ((total_count++))
  unzip_status=$(which unzip)
  if [[ -n $unzip_status ]]; then
    echo -e "unzip is \e[32minstalled\e[0m"
    unzip_status=true
    ((pass_count++))
  else
    echo -e "unzip is \e[31mnot installed\e[0m"
    unzip_status=false
  fi
  echo "### Check: $(print_status $unzip_status) ###"
}

function check_registry_cert () {
  echo "### Checking Registry Certificate ###"
  ((total_count++))
  if test -f "/etc/ssl/certs/${REGISTRY_FQDN}.pem"; then
    echo -e "Registry cert is \e[32minstalled\e[0m"
    ssl_store_status=true
    ((pass_count++))
  else
    echo -e "Registry cert \e[31mMissing from certificate store\e[0m"
    ssl_store_status=false
  fi
  echo "### Check: $(print_status $ssl_store_status) ###"

}

function check_registry_login () {
  echo "### Checking Registry Login ###"
  ((total_count++))
  if echo "$REGISTRY_PASSWORD" | docker login -u $REGISTRY_USERNAME --password-stdin "$REGISTRY_FQDN" 2>/dev/null; then
    echo -e "Registry login \e[32mSuccessful\e[0m"
    registry_login_status=true
    ((pass_count++))
  else
    echo -e "Registry login \e[31mFailed\e[0m"
    registry_login_status=false
  fi
  echo "### Check: $(print_status $registry_login_status) ###"
}

function check_dns_entries() {
  local dns1="$EO_FQDN"
  local dns2="mtls-$EO_FQDN"
  local dns3="mtls-recovery-$EO_FQDN"
  local dns4="$PORTAL_FQDN"
  local missing_entries=()

  if [[ $EO_FQDN == $mgmt_ip ]]; then
    echo -e "Orchestrator config is set to use IP, skipping DNS check"
    if [[ $EO_VERSION == "3.2" ]]; then
      echo -e "WARNING - DEPLOYING with IP IS NOT SUPPORTED IN 3.2"
    fi
    return 0
  fi 
  echo "### Checking Orchestrator DNS entries ###"
  ((total_count++))
  for entry in "$dns1" "$dns2" "$dns3" "$dns4"; do
    resolved_ip=$(host "$entry" 2>/dev/null | awk '/has address/ { print $4 }')
    if [[ -z "$resolved_ip" ]]; then
      missing_entries+=("$entry (not found)")
    elif [[ "$resolved_ip" != "$mgmt_ip" ]]; then
      missing_entries+=("$entry (IP mismatch: $resolved_ip)")
    fi
  done

  if [[ ${#missing_entries[@]} -eq 0 ]]; then
    ((pass_count++))
    dnsstatus=true
    echo -e "DNS check passed: All entries resolve to \e[32m$mgmt_ip\e[0m"
    echo "### Check: $(print_status $dnsstatus) ###"
  else
    dnsstatus=false
    echo -e "DNS check failed. \e[31mIssues found with the following entries\e[0m:"
    for entry in "${missing_entries[@]}"; do
      echo "  - $entry"
    done
    echo "Note that DNS check may be inacurate for 3.2 deployment, check official documentation or contact support for assistance."
    echo "### Check: $(print_status $dnsstatus) ###"
  fi
}

function pre_check_summary () {
  echo "#######################################################"
  echo "###    NativeEdge Orchestrator Pre-Check Summary    ###"
  echo "###    ${pass_count} of ${total_count} checks PASSED"
  if [[ $pass_count -eq $total_count ]]; then
    echo -e "###    \e[32mPre-Check Successful\e[0m"
    echo "#######################################################"
    echo "### Proceed to NativeEdge Orchestrator Installation ###"
    echo "#######################################################"
    pre_check_status=true
    echo "PRECHECK_STATUS=passed" > $logs_dir/pre-check-status.log
  else
    echo -e "###    \e[31mPre-Check Failed\e[0m"
    echo "#######################################################"
    echo "PRECHECK_STATUS=failed" > $logs_dir/pre-check-status.log
    exit 1
  fi
}

function run_pre_check () {
  check_modules
  echo ""
  check_sysctl
  echo ""
  check_swap
  echo ""
  check_runc
  echo ""
  check_containerd
  echo ""
  check_cni_plugins
  echo ""
  check_kube_apps
  echo ""
  check_kubernetes
  echo ""
  check_calico
  echo ""
  check_longhorn
  echo ""
  check_metallb
  echo ""
  check_scheduleable_storage
  echo ""
  check_memory_size
  echo ""
  check_cpu_count
  echo ""
  check_helm
  echo ""
  check_docker
  echo ""
  check_unzip
  echo ""
  check_registry_cert
  echo ""
  check_registry_login
  echo ""
  check_dns_entries
  echo ""
  pre_check_summary

}