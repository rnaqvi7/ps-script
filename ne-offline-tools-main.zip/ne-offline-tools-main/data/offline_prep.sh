#!/bin/bash

#This script is used to prepare the host for offline deployment of each available tool

# Associative array of URLs and their descriptions
declare -A urls=(
    ["https://pkgs.k8s.io"]="Kubernetes apt packages keyring"
    ["https://registry.k8s.io"]="Kubernetes Base Containers"
    ["https://mirror.gcr.io"]="Google Container Registry Mirror for Longhorn and Calico services"
    ["https://quay.io"]="Quay Container Registry for MetalLB services"
    ["https://canonical.com"]="Canonical (Ubuntu Publisher)"
    ["https://github.com"]="GitHub for containerd and harbor packages"
    ["https://docker.com"]="Docker apt keyring"
    ["https://dell.com"]="Dell Technologies for downloading Orchestrator Install Bundle"
    ["https://helm.sh"]="Helm Package Manager binary"
    ["https://ubuntu.com"]="Default Ubuntu apt package repositories"
    ["https://snapcraft.io"]="Snapcraft Store for optional tools"
)

# Array to store failed URLs
failed_urls=()

# Function to check URL reachability
function check_url() {
    url=$1
    description=$2
    if curl --output /dev/null --silent --head --fail --connect-timeout 10 "$url"; then
        echo -e "\e[32m $url is reachable\e[0m — $description"
    else
        echo -e "\e[31m $url is not reachable\e[0m — $description"
        failed_urls+=("$url — $description")
    fi
}


#functions

function prep_unzip_jq () {
    echo "Preparing unzip and jq packages..."
    echo "### Start prep_unzip_jq ###" >> $offline_prep_log
    local PACKAGES="unzip jq"
    local working_dir="$base_dir/data/unzip_jq/packages"
    mkdir -p $working_dir
    cd $working_dir
    if  ! check_prep_status; then
        apt_download_packs
        echo "Finished preparing unzip and jq packages..."
    else
        echo "Previous prep work detected, skipping..."
    fi
    echo "### Finished prep_unzip_jq ###" >> $offline_prep_log
}

function prep_nginx () {
    echo "Preparing NGINX packages..."
    echo "### Start prep_nginx ###" >> $offline_prep_log
    local PACKAGES="nginx apache2-utils"
    local working_dir="$base_dir/data/nginx/packages"
    if ! check_prep_status; then
      mkdir -p $working_dir
      cd $working_dir
      apt_download_packs
      echo "Finished preparing nginx packages"
    else
      echo "Previous prep work detected, skipping..."
    fi
    echo "### Finished prep_nginx ###" >> $offline_prep_log
}

function prep_docker () {
    echo "Preparing Docker packages..."
    echo "### Start prep_docker ###" >> $offline_prep_log
    local PACKAGES="docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin"
    local working_dir="$base_dir/data/docker/packages"
    if ! check_prep_status; then
      mkdir -p $working_dir
      cd $working_dir
      install -m 0755 -d /etc/apt/keyrings
      curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
      chmod a+r /etc/apt/keyrings/docker.asc
      echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
      apt-get update >> $offline_prep_log
      apt_download_packs
      echo "Finished preparing docker packages"
    else
      echo "Previous prep work detected, skipping..."
    fi
    echo "### Finished prep_docker ###" >> $offline_prep_log
}

function prep_containerd () {
    echo "Preparing containerd packages..."
    #runc
    local working_dir="$base_dir/data/k8s/packages/runc"
    echo "### Start prep_containerd ###" >> $offline_prep_log
    if ! check_prep_status; then
      mkdir -p $working_dir
      curl -fsSLo $working_dir/runc.amd64 https://github.com/opencontainers/runc/releases/download/v1.1.14/runc.amd64
      echo -e "Done" | tee $working_dir/prep.done
    else
      echo "Previous prep work detected, skipping..."
    fi
    #containerd
    local working_dir="$base_dir/data/k8s/packages/containerd"
    if ! check_prep_status; then
      mkdir -p $working_dir
      curl -fsSLo $working_dir/containerd-1.7.21-linux-amd64.tar.gz https://github.com/containerd/containerd/releases/download/v1.7.21/containerd-1.7.21-linux-amd64.tar.gz
      echo -e "Done" | tee $working_dir/prep.done
    else
      echo "Previous prep work detected, skipping..."
    fi
    #cni
    local working_dir="$base_dir/data/k8s/packages/cni"
    if ! check_prep_status; then
      mkdir -p $working_dir
      curl -fsSLo $working_dir/cni-plugins-linux-amd64-v1.5.1.tgz https://github.com/containernetworking/plugins/releases/download/v1.5.1/cni-plugins-linux-amd64-v1.5.1.tgz
      echo -e "Done" | tee $working_dir/prep.done
    else
      echo "Previous prep work detected, skipping..."
    fi
    echo "### Finished prep_containerd ###" >> $offline_prep_log
}

function prep_kube_apps () {
    echo "Preparing kubernetes packages..."
    echo "### Start prep_kube_apps ###" >> $offline_prep_log
    local PACKAGES="kubectl kubeadm kubelet open-iscsi"
    local working_dir="$base_dir/data/k8s/packages/kube_apps"
    if ! check_prep_status; then
      mkdir -p $working_dir
      curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.30/deb/Release.key | gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg
      echo "deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.30/deb/ /" | tee /etc/apt/sources.list.d/kubernetes.list
      apt-get update >> $offline_prep_log
      cd "$working_dir"
      apt_download_packs
      echo "Finished preparing kubernetes packages"
    else
      echo "Previous prep work detected, skipping..."
    fi
    echo "### Finished prep_kube_apps ###" >> $offline_prep_log
}

function prep_k8s_containers () {
    echo "Preparing k8s container images..."
    echo "This step requires containerd installing..."
    source $base_dir/data/k8s/install_k8s.sh
    add_modules
    update_sysctl
    disable_swap
    install_runc
    install_containerd
    install_cni_plugins
    echo "Containerd installed, continuing..."
    pull_kube_images
    pull_calico_images
    pull_longhorn_images
    pull_metallb_images
}

function prep_helm () {
    echo "Preparing helm packages..."
    echo "### Start prep_helm ###" >> $offline_prep_log
    local working_dir="$base_dir/data/k8s/packages/helm"
    if ! check_prep_status; then
      mkdir -p $working_dir
      curl -fsSLo $working_dir/helm-v$HELM_VERSION-linux-amd64.tar.gz https://get.helm.sh/helm-v$HELM_VERSION-linux-amd64.tar.gz
      echo -e "Done" | tee $working_dir/prep.done
    else
      echo "Previous prep work detected, skipping..."
    fi
    echo "### Finished prep_helm ###" >> $offline_prep_log
    
}
function prep_harbor () {
    echo "Preparing harbor packages..."
    echo "### Start prep_harbor ###" >> $offline_prep_log
    local working_dir="$base_dir/data/registry/packages"
    if ! check_prep_status; then
      mkdir -p $working_dir
      curl -fsSLo $working_dir/harbor-offline-installer-v$HARBOR_VERSION.tgz https://github.com/goharbor/harbor/releases/download/v$HARBOR_VERSION/harbor-offline-installer-v$HARBOR_VERSION.tgz
      echo -e "Done" | tee $working_dir/prep.done
    else
      echo "ERROR: Missing files or previous prep-work detected, check directory, remove all files from $working_dir and try again."
    fi
    echo "### Finished prep_harbor ###" >> $offline_prep_log
    
}

function pull_kube_images () {
    # Create working directory
    local working_dir="$base_dir/data/k8s/images/kube"
    echo "### Started pull_kube_images ###" >> $offline_prep_log
    mkdir -p $working_dir
    cd $working_dir

    echo "Pulling k8s base images..."
    ctr -n k8s.io image pull "$KUBE_METRICS_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_COREDNS_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_ETCD_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_APISERVER_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_CONTROLLER_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_PROXY_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_SCHEDULER_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_PAUSE_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_COREDNS_DIGEST_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_ETCD_DIGEST_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_APISERVER_DIGEST_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_CONTROLLER_DIGEST_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_PROXY_DIGEST_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_SCHEDULER_DIGEST_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$KUBE_PAUSE_DIGEST_IMAGE" >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull "$HAPROXY_IMAGE" >> $offline_prep_log 2>&1

    echo "Exporting k8s base images..."
    local metrics_tar="$(basename $KUBE_METRICS_IMAGE | cut -d: -f1).$(basename $KUBE_METRICS_IMAGE | cut -d: -f2).tar"
    local coredns_tar="$(basename $KUBE_COREDNS_IMAGE | cut -d: -f1).$(basename $KUBE_COREDNS_IMAGE | cut -d: -f2).tar"
    local etcd_tar="$(basename $KUBE_ETCD_IMAGE | cut -d: -f1).$(basename $KUBE_ETCD_IMAGE | cut -d: -f2).tar"
    local apiserver_tar="$(basename $KUBE_APISERVER_IMAGE | cut -d: -f1).$(basename $KUBE_APISERVER_IMAGE | cut -d: -f2).tar"
    local controller_tar="$(basename $KUBE_CONTROLLER_IMAGE | cut -d: -f1).$(basename $KUBE_CONTROLLER_IMAGE | cut -d: -f2).tar"
    local proxy_tar="$(basename $KUBE_PROXY_IMAGE | cut -d: -f1).$(basename $KUBE_PROXY_IMAGE | cut -d: -f2).tar"
    local scheduler_tar="$(basename $KUBE_SCHEDULER_IMAGE | cut -d: -f1).$(basename $KUBE_SCHEDULER_IMAGE | cut -d: -f2).tar"
    local pause_tar="$(basename $KUBE_PAUSE_IMAGE | cut -d: -f1).$(basename $KUBE_PAUSE_IMAGE | cut -d: -f2).tar"
    local coredns_digest_tar="$(basename $KUBE_COREDNS_DIGEST_IMAGE | cut -d@ -f1).sha256.$(basename $KUBE_COREDNS_DIGEST_IMAGE | cut -d: -f2).tar"
    local etcd_digest_tar="$(basename $KUBE_ETCD_DIGEST_IMAGE | cut -d@ -f1).sha256.$(basename $KUBE_ETCD_DIGEST_IMAGE | cut -d: -f2).tar"
    local apiserver_digest_tar="$(basename $KUBE_APISERVER_DIGEST_IMAGE | cut -d@ -f1).sha256.$(basename $KUBE_APISERVER_DIGEST_IMAGE | cut -d: -f2).tar"
    local controller_digest_tar="$(basename $KUBE_CONTROLLER_DIGEST_IMAGE | cut -d@ -f1).sha256.$(basename $KUBE_CONTROLLER_DIGEST_IMAGE | cut -d: -f2).tar"
    local proxy_digest_tar="$(basename $KUBE_PROXY_DIGEST_IMAGE | cut -d@ -f1).sha256.$(basename $KUBE_PROXY_DIGEST_IMAGE | cut -d: -f2).tar"
    local scheduler_digest_tar="$(basename $KUBE_SCHEDULER_DIGEST_IMAGE | cut -d@ -f1).sha256.$(basename $KUBE_SCHEDULER_DIGEST_IMAGE | cut -d: -f2).tar"
    local pause_digest_tar="$(basename $KUBE_PAUSE_DIGEST_IMAGE | cut -d@ -f1).sha256.$(basename $KUBE_PAUSE_DIGEST_IMAGE | cut -d: -f2).tar"
    local haproxy_tar="$(basename $HAPROXY_IMAGE | cut -d: -f1).$(basename $HAPROXY_IMAGE | cut -d: -f2).tar"
    ctr -n k8s.io image export "$metrics_tar" "$KUBE_METRICS_IMAGE"
    ctr -n k8s.io image export "$coredns_tar" "$KUBE_COREDNS_IMAGE"
    ctr -n k8s.io image export "$etcd_tar" "$KUBE_ETCD_IMAGE"
    ctr -n k8s.io image export "$apiserver_tar" "$KUBE_APISERVER_IMAGE"
    ctr -n k8s.io image export "$controller_tar" "$KUBE_CONTROLLER_IMAGE"
    ctr -n k8s.io image export "$proxy_tar" "$KUBE_PROXY_IMAGE"
    ctr -n k8s.io image export "$scheduler_tar" "$KUBE_SCHEDULER_IMAGE"
    ctr -n k8s.io image export "$pause_tar" "$KUBE_PAUSE_IMAGE"
    ctr -n k8s.io image export "$coredns_digest_tar" "$KUBE_COREDNS_DIGEST_IMAGE"
    ctr -n k8s.io image export "$etcd_digest_tar" "$KUBE_ETCD_DIGEST_IMAGE"
    ctr -n k8s.io image export "$apiserver_digest_tar" "$KUBE_APISERVER_DIGEST_IMAGE"
    ctr -n k8s.io image export "$controller_digest_tar" "$KUBE_CONTROLLER_DIGEST_IMAGE"
    ctr -n k8s.io image export "$proxy_digest_tar" "$KUBE_PROXY_DIGEST_IMAGE"
    ctr -n k8s.io image export "$scheduler_digest_tar" "$KUBE_SCHEDULER_DIGEST_IMAGE"
    ctr -n k8s.io image export "$pause_digest_tar" "$KUBE_PAUSE_DIGEST_IMAGE"
    ctr -n k8s.io image export "$haproxy_tar" "$HAPROXY_IMAGE"
    echo -e "Done" | tee $working_dir/prep.done
    echo "### Finished pull_k8s_images ###" >> $offline_prep_log
}

function pull_calico_images () {

    # Create working directory
    local working_dir="$base_dir/data/k8s/images/calico"
    echo "### Started pull_calico_images ###" >> $offline_prep_log
    mkdir -p $working_dir
    cd $working_dir

    echo "Pulling Calico images..."
    ctr -n k8s.io image pull $CALICO_CNI_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $CALICO_CONTROLLER_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $CALICO_NODE_IMAGE >> $offline_prep_log 2>&1

    echo "Exporting Calico images..."
    local cni_tar="$(basename $CALICO_CNI_IMAGE | cut -d: -f1).$(basename $CALICO_CNI_IMAGE | cut -d: -f2).tar"
    local controller_tar="$(basename $CALICO_CONTROLLER_IMAGE | cut -d: -f1).$(basename $CALICO_CONTROLLER_IMAGE | cut -d: -f2).tar" 
    local node_tar="$(basename $CALICO_NODE_IMAGE | cut -d: -f1).$(basename $CALICO_NODE_IMAGE | cut -d: -f2).tar" 
    ctr -n k8s.io image export $cni_tar $CALICO_CNI_IMAGE
    ctr -n k8s.io image export $controller_tar $CALICO_CONTROLLER_IMAGE
    ctr -n k8s.io image export $node_tar $CALICO_NODE_IMAGE
    echo -e "Done" | tee $working_dir/prep.done
    echo "### Finished pull_calico_images ###" >> $offline_prep_log
}

function pull_longhorn_images () {

    # Create working directory
    local working_dir="$base_dir/data/k8s/images/longhorn"
    echo "### Started pull_longhorn_images ###" >> $offline_prep_log
    mkdir -p $working_dir
    cd $working_dir

    echo "Pulling Longhorn images..."
    ctr -n k8s.io image pull $LONGHORN_BACKING_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_ATTACHER_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_REGISTRAR_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_PROVISIONER_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_RESIZER_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_SNAPSHOTTER_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_LIVENESSPROBE_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_ENGINE_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_INSTANCE_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_MANAGER_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_SHARE_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_UI_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $LONGHORN_SUPPORT_IMAGE >> $offline_prep_log 2>&1

    echo "Exporting Longhorn images..."
    local backing_tar="$(basename $LONGHORN_BACKING_IMAGE | cut -d: -f1).$(basename $LONGHORN_BACKING_IMAGE | cut -d: -f2).tar"
    local attacher_tar="$(basename $LONGHORN_ATTACHER_IMAGE | cut -d: -f1).$(basename $LONGHORN_ATTACHER_IMAGE | cut -d: -f2).tar"
    local registrar_tar="$(basename $LONGHORN_REGISTRAR_IMAGE | cut -d: -f1).$(basename $LONGHORN_REGISTRAR_IMAGE | cut -d: -f2).tar"
    local provisioner_tar="$(basename $LONGHORN_PROVISIONER_IMAGE | cut -d: -f1).$(basename $LONGHORN_PROVISIONER_IMAGE | cut -d: -f2).tar"
    local resizer_tar="$(basename $LONGHORN_RESIZER_IMAGE | cut -d: -f1).$(basename $LONGHORN_RESIZER_IMAGE | cut -d: -f2).tar"
    local snapshotter_tar="$(basename $LONGHORN_SNAPSHOTTER_IMAGE | cut -d: -f1).$(basename $LONGHORN_SNAPSHOTTER_IMAGE | cut -d: -f2).tar"
    local livenessprobe_tar="$(basename $LONGHORN_LIVENESSPROBE_IMAGE | cut -d: -f1).$(basename $LONGHORN_LIVENESSPROBE_IMAGE | cut -d: -f2).tar"
    local engine_tar="$(basename $LONGHORN_ENGINE_IMAGE | cut -d: -f1).$(basename $LONGHORN_ENGINE_IMAGE | cut -d: -f2).tar"
    local instance_tar="$(basename $LONGHORN_INSTANCE_IMAGE | cut -d: -f1).$(basename $LONGHORN_INSTANCE_IMAGE | cut -d: -f2).tar"
    local manager_tar="$(basename $LONGHORN_MANAGER_IMAGE | cut -d: -f1).$(basename $LONGHORN_MANAGER_IMAGE | cut -d: -f2).tar"
    local share_tar="$(basename $LONGHORN_SHARE_IMAGE | cut -d: -f1).$(basename $LONGHORN_SHARE_IMAGE | cut -d: -f2).tar"
    local ui_tar="$(basename $LONGHORN_UI_IMAGE | cut -d: -f1).$(basename $LONGHORN_UI_IMAGE | cut -d: -f2).tar"   
    local support_tar="$(basename $LONGHORN_SUPPORT_IMAGE | cut -d: -f1).$(basename $LONGHORN_SUPPORT_IMAGE | cut -d: -f2).tar" 
    ctr -n k8s.io image export $backing_tar $LONGHORN_BACKING_IMAGE
    ctr -n k8s.io image export $attacher_tar $LONGHORN_ATTACHER_IMAGE
    ctr -n k8s.io image export $registrar_tar $LONGHORN_REGISTRAR_IMAGE
    ctr -n k8s.io image export $provisioner_tar $LONGHORN_PROVISIONER_IMAGE
    ctr -n k8s.io image export $resizer_tar $LONGHORN_RESIZER_IMAGE
    ctr -n k8s.io image export $snapshotter_tar $LONGHORN_SNAPSHOTTER_IMAGE
    ctr -n k8s.io image export $livenessprobe_tar $LONGHORN_LIVENESSPROBE_IMAGE
    ctr -n k8s.io image export $engine_tar $LONGHORN_ENGINE_IMAGE
    ctr -n k8s.io image export $instance_tar $LONGHORN_INSTANCE_IMAGE
    ctr -n k8s.io image export $manager_tar $LONGHORN_MANAGER_IMAGE
    ctr -n k8s.io image export $share_tar $LONGHORN_SHARE_IMAGE
    ctr -n k8s.io image export $ui_tar $LONGHORN_UI_IMAGE
    ctr -n k8s.io image export $support_tar $LONGHORN_SUPPORT_IMAGE
    echo -e "Done" | tee $working_dir/prep.done
    echo "### Finished pull_longhorn_images ###" >> $offline_prep_log
}

function pull_metallb_images() {

    # Create working directory
    local working_dir="$base_dir/data/k8s/images/metallb"
    echo "### Started pull_metallb_images ###" >> $offline_prep_log
    mkdir -p "$working_dir"
    cd "$working_dir"

    echo "Pulling MetalLB images..."
    ctr -n k8s.io image pull $METALLB_CONTROLLER_IMAGE >> $offline_prep_log 2>&1
    ctr -n k8s.io image pull $METALLB_SPEAKER_IMAGE >> $offline_prep_log 2>&1

    echo "Exporting MetalLB images..."
    local controller_tar="$(basename $METALLB_CONTROLLER_IMAGE | cut -d: -f1).$(basename $METALLB_CONTROLLER_IMAGE | cut -d: -f2).tar"
    local speaker_tar="$(basename $METALLB_SPEAKER_IMAGE | cut -d: -f1).$(basename $METALLB_SPEAKER_IMAGE | cut -d: -f2).tar"
    ctr -n k8s.io image export $controller_tar $METALLB_CONTROLLER_IMAGE
    ctr -n k8s.io image export $speaker_tar $METALLB_SPEAKER_IMAGE
    echo -e "Done" | tee $working_dir/prep.done
    echo "### Finished pull_metallb_images ###" >> $offline_prep_log
}

function install_dpkg_dev() {
  if ! dpkg -s dpkg-dev &> /dev/null; then
    echo "dpkg-dev missing. Installing..."
    echo "### install_dpkg_dev started ###" >> $offline_prep_log
    apt-get update -qq >> $offline_prep_log
    DEBIAN_FRONTEND=noninteractive apt-get install -y dpkg-dev >> $offline_prep_log
    echo "### install_dpkh_dev finished ###" >> $offline_prep_log
  else
    echo "dpkg-dev is already installed. Continuing..."
  fi
}

function apt_download_packs () {
    echo "Downloading $PACKAGES ..."
    apt-get download $(apt-cache depends --recurse --no-recommends --no-suggests --no-conflicts --no-breaks --no-replaces --no-enhances --no-pre-depends ${PACKAGES} | grep "^\w")  >> $offline_prep_log 2>&1
    dpkg-scanpackages -m . > Packages
    echo -e "Done" | tee prep.done
}

function set_prep_status () {
  if [[ $OFFLINE_PREP_STATUS == true ]]; then
    echo "OFFLINE_PREP_STATUS is $OFFLINE_PREP_STATUS, which indicates --offline-prep has already been completed"
    echo "To bypass, change data/.env OFFLINE_PREP_STATUS=false"
    exit 1
  else
    echo "running Offline Prep and setting OFFLINE_PREP_STATUS to true"
    echo "### Offline Prep Started ###" >> $offline_prep_log
    sed -i 's/OFFLINE_PREP_STATUS=false/OFFLINE_PREP_STATUS=true/' $base_dir/data/.env
  fi
}

function pull_helm_charts() {
  if [[ $EO_VERSION == "3.2" ]]; then
    echo "Pulling haproxytech/kubernetes-ingress helm chart..."
    helm repo add haproxytech https://haproxytech.github.io/helm-charts
    helm repo update
    mkdir -p $base_dir/data/k8s/packages/helm
    cd $base_dir/data/k8s/packages/helm
    helm pull haproxytech/kubernetes-ingress --version 1.44.4
    cd $base_dir
  fi
}