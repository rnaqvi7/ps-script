#!/bin/bash

# This script contains functions for installing and NGINX web server for serving satic files
# To be used with ne-tools.sh


### Functions

function nginx_check () {
    echo "### Started nginx_check ###" >> $install_artifact_server_log
    echo "Verifying and installing dependencies..."
    local working_dir="$base_dir/data/nginx/packages"
    if ! check_prep_status; then
        echo "Packages not prepared, try running --offline-prep first."
        exit 1
    fi
    if ! command -v nginx &> /dev/null; then
        echo "Installing NGINX..."
        if [[ $AIRGAPPED == "true" ]]; then
          local source_list_file="/etc/apt/sources.list.d/nginx.list"
          create_local_repo
        fi
        DEBIAN_FRONTEND=noninteractive apt-get -y install nginx >> $install_artifact_server_log
    else
        echo "NGINX is already installed!"
        echo "This script cannot verify existing NGINX configuration."
        echo "Try running --install-artifact-server on a freshly prepared host."
        exit 1
    fi
    if ! command -v htpasswd &> /dev/null
    then
        echo "Installing htpasswd..."
        DEBIAN_FRONTEND=noninteractive apt-get -y install apache2-utils >> $install_artifact_server_log
    else
        echo "htpasswd is already installed!"
    fi
    echo "### Finished nginx_check ###" >> $install_artifact_server_log
}

# Prepare directory structure
function prepare_dirs () {
    local working_dir="$base_dir/data/nginx"
    echo "Preparing directory structure..."
    rm /etc/nginx/sites-enabled/default
    mkdir -p /var/www/nginx/artifacts
    chown -R www-data:www-data /var/www/nginx
    mkdir $working_dir/certs
    mkdir -p /etc/nginx/certs/artifacts
    mkdir $working_dir/auth
    mkdir -p /etc/nginx/auth/artifacts
}

# Create self-signed certificates

function nginx_cert_gen () {
  local working_dir="$base_dir/data/nginx"
  local current_hostname=$(hostname)
  mkdir -p $working_dir/certs
  echo "Creating self-signed certificate valid for $DURATION_DAYS days..."
  # Generate CA key
  openssl genrsa -out $working_dir/certs/ca.key 4096
  # Generate CA certificate
  openssl req -x509 -new -nodes -sha512 -days $DURATION_DAYS -subj "/C=$COUNTRY/ST=$STATE/L=$LOCATION/O=$ORGANIZATION/CN=$ARTIFACT_COMMON_NAME" -key $working_dir/certs/ca.key -out $working_dir/certs/ca.crt
  # Generate server key
  openssl genrsa -out $working_dir/certs/$ARTIFACT_COMMON_NAME.key 4096
  # Generate server CSR
  openssl req -sha512 -new -subj "/C=$COUNTRY/ST=$STATE/L=$LOCATION/O=$ORGANIZATION/CN=$ARTIFACT_COMMON_NAME" -key $working_dir/certs/$ARTIFACT_COMMON_NAME.key -out $working_dir/certs/$ARTIFACT_COMMON_NAME.csr
  # Create v3 extension
  cat > $working_dir/certs/v3.ext <<-EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

[alt_names]
IP.1=$mgmt_ip
DNS.1=$ARTIFACT_COMMON_NAME
DNS.2=$current_hostname
EOF

  # Generate signed certificate
  openssl x509 -req -sha512 -days $DURATION_DAYS -extfile $working_dir/certs/v3.ext -CA $working_dir/certs/ca.crt -CAkey $working_dir/certs/ca.key -CAcreateserial -in $working_dir/certs/$ARTIFACT_COMMON_NAME.csr -out $working_dir/certs/$ARTIFACT_COMMON_NAME.crt

  echo "Completed generating certificates:"
  echo "CA certificate:"
  file "$working_dir/certs/ca.crt"
  echo "Server private key:"
  file "$working_dir/certs/$ARTIFACT_COMMON_NAME.key"
  echo "Server signed certificate:"
  file "$working_dir/certs/$ARTIFACT_COMMON_NAME.crt"
  cp $working_dir/certs/$ARTIFACT_COMMON_NAME.key /etc/nginx/certs/artifacts/
  cp $working_dir/certs/$ARTIFACT_COMMON_NAME.crt /etc/nginx/certs/artifacts/
}



# create htpasswd file for basic auth
function auth_gen () {
    local working_dir="$base_dir/data/nginx"
    echo "Creating a user for Artifact server authentication from .config file..."
    htpasswd -bc "$working_dir/auth/$ARTIFACT_COMMON_NAME-htpasswd" "$HTUSER" "$HTPASS"
    cp "$working_dir/auth/$ARTIFACT_COMMON_NAME-htpasswd" "/etc/nginx/auth/artifacts/$ARTIFACT_COMMON_NAME-htpasswd"
}

function conf_gen () {
    local working_dir="$base_dir/data/nginx"
    echo "Creating NGINX configuration file..."
    cat > $working_dir/web_data/$ARTIFACT_COMMON_NAME.conf <<EOF
# nginx server config created by ne-offline-tools
server {
        # http configuration
        #uncomment for basic http
        #Do not mix with ssl block
        #listen 80;
        #listen [::]:80;
 
        # SSL configuration
        #uncomment for https connection, must pre-create self-signed certificates
        #Do not mix with http block
        listen $NGINX_PORT ssl;
        listen [::]:$NGINX_PORT ssl;
        ssl_certificate /etc/nginx/certs/artifacts/$ARTIFACT_COMMON_NAME.crt;
        ssl_certificate_key /etc/nginx/certs/artifacts/$ARTIFACT_COMMON_NAME.key;
        ssl_session_timeout 10m;
         
        # root directory for your webserver
        #www-data user must be owner and group
        root /var/www/nginx;
        index index.html;

        server_name _;
 
        location / {
                try_files \$uri \$uri/ =404;
                # Basic authentication comment out if no password is required
                auth_basic "Login Required";
                auth_basic_user_file /etc/nginx/auth/artifacts/$ARTIFACT_COMMON_NAME-htpasswd;
        }
        location /artifacts {
                autoindex on;
                try_files \$uri \$uri/ =404;
                # Basic authentication, comment out if no password is required
                auth_basic "Login Required";
                auth_basic_user_file /etc/nginx/auth/artifacts/$ARTIFACT_COMMON_NAME-htpasswd;
        }
}
EOF
}


# Test server and apply
function apply_server () {
    local working_dir="$base_dir/data/nginx"
    echo "Applying server config..."
    cp $working_dir/web_data/index.html /var/www/nginx/
    cp $working_dir/web_data/$ARTIFACT_COMMON_NAME.conf /etc/nginx/sites-available/$ARTIFACT_COMMON_NAME.conf
    ln -s /etc/nginx/sites-available/$ARTIFACT_COMMON_NAME.conf /etc/nginx/sites-enabled/
    echo "Verifying configuration and reloading NGINX..."
    nginx -t
    systemctl restart nginx
}

function gen_curl_header () {
  base64_auth_string=$(echo -n "$HTUSER:$HTPASS" | base64)
}