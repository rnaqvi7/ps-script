#!/bin/bash

function install_docker () {
    echo "Installing docker..."
    local user=$SUDO_USER
    if [[ $AIRGAPPED == "true" ]]; then
      local working_dir="$base_dir/data/docker/packages"
      local source_list_file="/etc/apt/sources.list.d/docker.list"
      create_local_repo
    fi
    create_bridge_json
    echo "" | DEBIAN_FRONTEND=noninteractive apt-get -y -qq install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin >> $logs_dir/common.log
    usermod -aG docker $user
}

function create_bridge_json () {
  echo "pre-creating docker bridge json..."
  mkdir -p /etc/docker
  cat <<EOF | tee /etc/docker/daemon.json > /dev/null
{
  "bip": "$DOCKER_BRIDGE_CIDR"
}
EOF
  echo "Created /etc/docker/daemon.json with bip: $DOCKER_BRIDGE_CIDR"
}