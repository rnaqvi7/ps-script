#!/bin/bash
# This script holds functions for generating kubernetes manifets and config yaml
# WIP

function create_kubeconfig () {
    echo "Creating kubeconfig file for $host_name..."
    cat > $services_dir/k8s-singlenode.yaml <<EOF
apiVersion: kubeadm.k8s.io/v1beta3
kind: InitConfiguration
nodeRegistration:
  imagePullPolicy: "$KUBE_IMAGE_PULL_POLICY"
---
apiVersion: kubeadm.k8s.io/v1beta3
kind: ClusterConfiguration
controlPlaneEndpoint: "$host_name:6443"
kubernetesVersion: "v$K8S_VERSION"
networking:
  podSubnet: "$POD_SUBNET"
  serviceSubnet: "$SERVICE_SUBNET"
---
apiVersion: kubelet.config.k8s.io/v1beta1
kind: KubeletConfiguration
serverTLSBootstrap: true
maxPods: 150
EOF
echo "kubeconfig file created..."
}

function create_IPAddressPool () {
    echo "Creating IPAddressPool resource file for MetalLB with $mgmt_ip..."
    cat > $services_dir/metallb_IPAddressPool.yaml <<EOF
apiVersion: metallb.io/v1beta1
kind: IPAddressPool
metadata:
  namespace: metallb-system
  name: default
spec:
  addresses:
  - $mgmt_ip/32
EOF
}

function create_NodePort () {
    echo "Creating NodePort resource file for Longhorn UI on port 31000..."
    cat > $services_dir/longhorn_NodePort.yaml <<EOF
apiVersion: v1
kind: Service
metadata:
  name: longhorn-nodeport-svc
  namespace: longhorn-system
spec:
  type: NodePort
  ports:
  - name: http
    nodePort: 31000
    port: 80
    protocol: TCP
    targetPort: http
  selector:
    app: longhorn-ui
  sessionAffinity: None
EOF
}

function apply_calico_config () {
  echo "Creating Calico manifest..."
}

function create_metrics_config () {
  echo "Creating metrics-server manifest..."
}

function create_longhorn_config () {
  echo "Creating Longhorn manifest..."
}

function create_metallb_config () {
  echo "Creating MetalLB manifest..."
}