#!/bin/bash

# This script will install pre-reqs for a single-node k8s cluster to support a NativeEdge Orchestrator deployment

### Variables ###
user_name=$(logname)
host_name=$(hostname)
ntp_server=""
services_dir="$base_dir/data/k8s/manifests/services"
found_images=true

### Functions ###

function add_modules () {
    echo "Enabling overlay and br_netfilter modules..."
    echo "### Start add_modules ###" >> $install_k8s_log
    echo -e "overlay\nbr_netfilter" | tee /etc/modules-load.d/containerd.conf
    modprobe -a overlay br_netfilter >> $install_k8s_log
    echo "### End add_modules ###" >> $install_k8s_log
}

function update_sysctl () {
    echo "Applying sysctl settings for NativeEdge and Kubernetes..."
    echo "### Start update_sysctl ###" >> $install_k8s_log
    echo -e "fs.inotify.max_user_watches = 1048576\nfs.inotify.max_user_instances = 1024" | tee /etc/sysctl.d/10-nativeedge-orchestrator.conf
    echo -e "net.bridge.bridge-nf-call-ip6tables = 1\nnet.bridge.bridge-nf-call-iptables = 1\nnet.ipv4.ip_forward = 1" | tee /etc/sysctl.d/10-kubernetes.conf
    sysctl --system >> "$install_k8s_log"
    echo "### End update_sysctl ###" >> "$install_k8s_log"
}

function disable_swap () {
    echo "Disabling swap space..."
    swapoff -a
    sed -i -e '/swap/d' /etc/fstab
}

function install_runc () {
    echo "Installing low-level container runtime runc..."
    local working_dir="$base_dir/data/k8s/packages/runc"
    if check_prep_status; then
      echo "Confirmed $working_dir"
      install -m 755 $working_dir/runc.amd64 /usr/local/sbin/runc
    else
      echo "Packages not prepared, try running --offline-prep first."
      exit 1
    fi
}

function install_containerd () {
    echo "Installing containerd..."
    local working_dir="$base_dir/data/k8s/packages/containerd"
    if check_prep_status; then
      echo "Confirmed $working_dir"
      local working_dir="$base_dir/data/k8s"
      mkdir /etc/containerd
      cp $working_dir/manifests/containerd/config.toml /etc/containerd/config.toml
      tar Cxzf /usr/local $working_dir/packages/containerd/containerd-1.7.21-linux-amd64.tar.gz
      cp $working_dir/manifests/containerd/containerd.service /etc/systemd/system/containerd.service
      systemctl daemon-reload
      systemctl enable --now containerd
    else
      echo "Packages not prepared, try running --offline-prep first."
      exit 1
    fi
}

function install_cni_plugins () {
    echo "Installing CNI plugins..."
    local working_dir="$base_dir/data/k8s/packages/cni"
    if check_prep_status; then
      echo "Confirmed $working_dir"
      mkdir -p /opt/cni/bin
      tar Cxzf /opt/cni/bin $working_dir/cni-plugins-linux-amd64-v1.5.1.tgz
    else
      echo "Packages not prepared, try running --offline-prep first."
      exit 1
    fi
}

function install_kube_apps () {
    echo "Installing kubeadm, kubelet, kubectl, and open-iscsi..."
    if [[ $AIRGAPPED == "true" ]]; then 
      local working_dir="$base_dir/data/k8s/packages/kube_apps"
      local source_list_file="/etc/apt/sources.list.d/kubernetes.list"
      create_local_repo
    fi
    DEBIAN_FRONTEND=noninteractive apt-get -y install kubeadm kubelet kubectl open-iscsi >> $install_k8s_log
    apt-mark hold kubeadm kubelet kubectl >> $install_k8s_log
}

function create_kubeconfig () {
    echo "Creating kubeconfig file for $host_name..."
    cat > $services_dir/k8s-singlenode.yaml <<EOF
apiVersion: kubeadm.k8s.io/v1beta3
kind: InitConfiguration
nodeRegistration:
  imagePullPolicy: "$KUBE_IMAGE_PULL_POLICY"
---
apiVersion: kubeadm.k8s.io/v1beta3
kind: ClusterConfiguration
controlPlaneEndpoint: "$K8S_CONTROLPLANE_FQDN:6443"
kubernetesVersion: "v$K8S_VERSION"
networking:
  podSubnet: "$POD_SUBNET"
  serviceSubnet: "$SERVICE_SUBNET"
---
apiVersion: kubelet.config.k8s.io/v1beta1
kind: KubeletConfiguration
serverTLSBootstrap: true
maxPods: 180
EOF
  if [[ $TLS_MIN_VERSION == VersionTLS13 ]]; then
    cat >> $services_dir/k8s-singlenode.yaml <<EOF
tlsMinVersion: "$TLS_MIN_VERSION"
EOF
  fi
echo "kubeconfig file created..."
}

function create_IPAddressPool () {
    echo "Creating IPAddressPool resource file for MetalLB with $mgmt_ip..."
    cat > $services_dir/metallb_IPAddressPool.yaml <<EOF
apiVersion: metallb.io/v1beta1
kind: IPAddressPool
metadata:
  namespace: metallb-system
  name: default
spec:
  addresses:
  - $mgmt_ip/32
EOF
}

function create_L2Advertisement () {
    echo "Creating L2Advertisement resource file for MetalLB with $mgmt_if..."
    cat > $services_dir/metallb_L2Advertisement.yaml <<EOF
apiVersion: metallb.io/v1beta1
kind: L2Advertisement
metadata:
  namespace: metallb-system
  name: default
spec:
  ipAddressPools:
  - default
  interfaces:
  - $mgmt_if
EOF
}

function create_NodePort () {
    echo "Creating NodePort resource file for Longhorn UI on port 31000..."
    cat > $services_dir/longhorn_NodePort.yaml <<EOF
apiVersion: v1
kind: Service
metadata:
  name: longhorn-nodeport-svc
  namespace: longhorn-system
spec:
  type: NodePort
  ports:
  - name: http
    nodePort: 31000
    port: 80
    protocol: TCP
    targetPort: http
  selector:
    app: longhorn-ui
  sessionAffinity: None
EOF
}

# Function to check if pods are ready
function check_pods_ready() {
  while [ $(kubectl get pods -A --no-headers | awk '{print $3}' | awk -F'/' '{if ($1 != $2) print $0}' |wc -l) -ne 0 ]; do
    kubectl get pods -A
    echo "Waiting for all pods to be ready..."
    sleep 15
  done
  kubectl get pods -A
  echo "All pods are ready!"
}

#function to prompt user for registry certificate

function init_k8s_singlenode() {
  # create kubeadm config
  echo "Checking DNS configuration fron .config ..."
  if [[ $USE_EXTERNAL_DNS == false ]]; then
    echo "USE_EXTERNAL_DNS is set to false"
    echo "Setting /etc/hosts entry for $REGISTRY_FQDN..."
    echo "$REGISTRY_IP $REGISTRY_FQDN" | tee -a /etc/hosts
    echo "coreDNS patch will be applied..."
  else
    echo "USE_EXTERNAL_DNS is set to true"
    echo "Using standard coreDNS configuration..."
  fi
  echo -e "k8s controlPlaneEndpoint will be set to K8S_CONTROLPLANE_FQDN value of $K8S_CONTROLPLANE_FQDN"
  echo "Adding $K8S_CONTROLPLANE_FQDN to /etc/hosts using $mgmt_ip..."
  echo "$mgmt_ip $K8S_CONTROLPLANE_FQDN" | tee -a /etc/hosts
  create_kubeconfig
  local kubeadm_file="$services_dir/k8s-singlenode.yaml"
  echo "Running Kubeadm initialization..."
  echo "kubeadm init --upload-certs --config=$kubeadm_file"
  output=$(kubeadm init --upload-certs --config=$kubeadm_file 2>&1)
  exit_code=$?

  # Check if kubeadm init was successful
  if [ $exit_code -eq 0 ]; then
    echo "$output" >> $install_k8s_log
    echo "$output"
    echo "#############################################"
    echo "### Kubeadm init completed SUCCESSFULLY   ###"
    echo "#############################################"
  else
    echo "$output"
    echo "#############################################"
    echo "### Kubeadm init FAILED check data/logs/  ###"
    echo "#############################################"
    exit $exit_code
  fi

  # copy kubectl config and list nodes
  echo "Updating kubectl config files..."
  mkdir -p /home/$user_name/.kube
  mkdir /root/.kube
  cp -i /etc/kubernetes/admin.conf /home/$user_name/.kube/config
  chown $user_name:$user_name /home/$user_name/.kube/config
  cp -i /etc/kubernetes/admin.conf /root/.kube/config
  kubectl get nodes
  echo ""
  sleep 10

  # Accept certificates
  accept_csr
  echo ""

  # Untaint the node
  echo "Untainting all control-plane nodes for scheduling workloads"
  kubectl taint nodes --all node-role.kubernetes.io/control-plane-
  echo ""

  if [[ $USE_EXTERNAL_DNS == false ]]; then
    echo "Applying coredns patch..."
    kubectl -nkube-system patch configmap coredns --patch-file $services_dir/coredns-patch.yaml
    kubectl -nkube-system rollout restart deployment coredns
  fi

  # Message that Kubernetes cluster is ready for services
  echo "The Kubernetes cluster is ready for service configuration."
}

# Function to accept all pending k8s csr
function accept_csr() {
  echo "Approving any pending Kubernetes certificates..."
  kubectl get csr | grep Pending | awk '{print $1}' | xargs -I {} kubectl certificate approve {}
}

function check_ctr_images() {
  # This function takes a list of images as input and checks if they are present in the k8s.io namespace:
  # Example usage:
  # calico_images=("mirror.gcr.io/calico/cni:v3.28.0" "mirror.gcr.io/calico/kube-controllers:v3.28.0" "mirror.gcr.io/calico/node:v3.28.0")
  # check_ctr_images "${calico_images[@]}"
  # Get the list of images to check as input
  local images_to_check=("$@")

  # Run the command to get the list of images
  local images=$(ctr -n k8s.io images list)

  # Initialize found as true
  found_images=true

  # Check for each image in the list
  for image in "${images_to_check[@]}"; do
    if ! grep -q "$image" <<< "$images"; then
      found_images=false
      echo "Missing image: $image"
    fi
  done

  if [[ $found_images == true ]]; then
    echo "All images found in k8s.io namespace."
  else
    echo "Some images are missing in k8s.io namespace."
  fi
}

function import_images() {
  # This function imports images from a directory of tar files
  # Example usage:
  # import_images $images_directory
  # where images_directory=/path/to/your/tar/files 
  # Get the directory containing the tar files
  local images_dir="$1"

  # Check if the directory exists
  if [[ ! -d "$images_dir" ]]; then
    echo "Error: Directory '$images_dir' does not exist."
    return 1
  fi
  # Loop through each file in the directory
  for tar_file in "$images_dir"/*.tar; do
    # Check if it's a regular file
    if [[ ! -f "$tar_file" ]]; then
      continue
    fi

    # Import the image using ctr
    echo "Importing image: $tar_file"
    ctr -n k8s.io image import "$tar_file"
  done
}

function apply_calico () {
  echo "Applying Calico manifest..."
  kubectl apply -f $services_dir/calico-airgap-3.28.0.yaml >> $install_k8s_log
  sleep 5
  check_pods_ready
  echo "Calico manifest applied..."
}

function apply_metrics () {
  echo "Applying metrics-server manifest..."
  kubectl apply -f $services_dir/metrics-server-airgap-0.7.2-components.yaml >> $install_k8s_log
  sleep 5
  check_pods_ready
  echo "Metrics-server manifest applied..."
}

function apply_longhorn () {
  echo "Applying Longhorn manifest..."
  kubectl apply -f $services_dir/longhorn-airgap-1.8.2.yaml >> $install_k8s_log
  sleep 5
  check_pods_ready
  echo "Longhorn manifest applied..."
  create_NodePort
  echo "Applying NodePort to expose Longhorn UI..."
  kubectl apply -f $services_dir/longhorn_NodePort.yaml >> $install_k8s_log
}

function apply_metallb () {
  echo "Applying MetalLB manifest..."
  kubectl apply -f $services_dir/metallb-airgap-0.14.8.yaml >> $install_k8s_log
  sleep 5
  check_pods_ready
  create_IPAddressPool
  echo "Applying IPAddressPool..."
  kubectl apply -f $services_dir/metallb_IPAddressPool.yaml >> $install_k8s_log
  sleep 5
  create_L2Advertisement
  echo "Applying L2Advertisement..."
  kubectl apply -f $services_dir/metallb_L2Advertisement.yaml >> $install_k8s_log
}

function apply_haproxy () {
  echo "Applying Haproxy helm chart..."
  helm install haproxy $base_dir/data/k8s/packages/helm/kubernetes-ingress-1.44.4.tgz --namespace haproxy --create-namespace -f $base_dir/data/k8s/manifests/services/haproxy-values.yaml  >> $install_k8s_log
  echo "Haproxy manifest applied..."
}

function install_helm () {
  echo "Installing Helm..."
  local working_dir="$base_dir/data/k8s/packages/helm"
  if ! check_prep_status; then
    echo "ERROR: Missing helm package from $working_dir"
  else 
    tar xzvf $working_dir/helm-v$HELM_VERSION-linux-amd64.tar.gz -C $working_dir/ 2> /dev/null
    cp $working_dir/linux-amd64/helm /usr/local/bin/helm
  fi
}

function patch_tls_version () {
  if [[ $TLS_VERSION == "VersionTLS13" ]]; then
    echo "Patching TLS version to $TLS_MIN_VERSION..."
    sed -i '/- --tls-private-key-file=\/etc\/kubernetes\/pki\/apiserver.key/a\    - --tls-min-version=VersionTLS13' /etc/kubernetes/manifests/kube-apiserver.yaml
    sed -i '/- --trusted-ca-file=\/etc\/kubernetes\/pki\/etcd\/ca.crt/a\    - --tls-min-version=TLS1.3' /etc/kubernetes/manifests/etcd.yaml
    echo "Kubernetes has been patched to use TLS1.3"
    echo "Reboot of host recommened"
  fi
}