#!/bin/bash

set_ntp_servers () {
    echo "Updating NTP server configuration with $NTP_SERVERS from .config NTP_SERVERS variable..."
    if [[ -f /etc/systemd/timesyncd.conf.d/custom-ntp.conf ]]; then
      echo "Removing previous configuration..."
      rm /etc/systemd/timesyncd.conf.d/custom-ntp.conf
    fi
    if [[ ! -d /etc/systemd/timesyncd.conf.d ]]; then
      echo "Creating /etc/systemd/timesyncd.conf.d directory..."
      mkdir -p /etc/systemd/timesyncd.conf.d
    fi
    echo "creating custom NTP config file /etc/systemd/timesyncd.conf.d/custom-ntp.conf"
    cat > /etc/systemd/timesyncd.conf.d/custom-ntp.conf <<EOF
[Time]
NTP=$NTP_SERVERS
NTPFallback=$NTP_SERVERS
EOF
    timedatectl set-ntp true
    echo "Restarting systemd-timesyncd..."
    systemctl restart systemd-timesyncd
    echo "Checking NTP status..."
    timedatectl show-timesync --all
    timedatectl status
    echo "Update completed. Synchronization may take a few minutes, check status with 'timedatectl status' command."
}

check_ntp_status () {
  local ntp_sync_status=$(timedatectl status |grep System |awk '{print $4}')
  echo "Checking NTP status..."
  echo ""
  if [[ $ntp_sync_status == "yes" ]]; then
    echo -e "\e[32mNTP is synchronized!\e[0m"
    timedatectl status
  else
    echo -e "#### \e[31mWARNING NTP is not synchronized\e[0m ####"
    timedatectl status
    echo ""
    systemctl status systemd-timesyncd
    echo ""
    echo "Improper NTP sync may cause inconsistent behavior of Kubenetes services"
    echo "Check above output for more details. Try updating .config NTP_SERVERS varialbe with known good NTP servers and run --set-ntp-servers to resove the issue." 
    echo ""
  fi
}