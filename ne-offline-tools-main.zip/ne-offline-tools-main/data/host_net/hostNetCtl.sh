#!/bin/bash

# This script contains functions for updating the hostname and netplan configuration
# Part of ne-tools.sh --set-hostname & --set-static-ip

function hostname_ctl () {
  current_hostname=$(hostname)

  echo "Current hostname is: $current_hostname"
  echo "Enter desired hostname:"
  read new_hostname

  echo "Updating /etc/hosts and hostname..."
  sed -i "s/$current_hostname/$new_hostname/g" /etc/hosts
  hostnamectl set-hostname $new_hostname
  echo ""
  echo "New hostname set to $new_hostname"
}

function static_ip_ctl () {
  
  local working_dir="$base_dir/data/host_net"
  timestamp=$(date +%Y-%m-%d-%H-%M-%S)

  echo "Cleaning up any previous config..."
  rm $working_dir/10-static-$mgmt_if.yaml &> /dev/null

  echo "Current IP & interface are: $mgmt_ip, $mgmt_if"

  echo "Static IP inputs needed..."
  echo "Enter desired IP CIDR (i.e. 192.168.1.50/24):"
  read new_ip
  echo "Enter the default gateway IP:"
  read new_gtwy
  echo "Enter the DNS IPs, comma separated (Optional):"
  read new_dns
  echo "Enter the DNS search domains, comma separated (Optional):"
  read new_dns_search
  echo ""

  echo "Generating a netplan file from inputs..."
  cat > $working_dir/10-static-$mgmt_if.yaml <<EOF
# This is the network config written by ne-tools.sh
network:
  ethernets:
    $mgmt_if:
      addresses:
      - $new_ip
EOF

  if [ -n "$new_dns" ] || [ -n "$new_dns_search" ]; then
    cat >> $working_dir/10-static-$mgmt_if.yaml <<EOF
      nameservers:
EOF
    if [ -n "$new_dns" ]; then
      cat >> $working_dir/10-static-$mgmt_if.yaml <<EOF
        addresses: [$new_dns]
EOF
    fi
    if [ -n "$new_dns_search" ]; then
      cat >> $working_dir/10-static-$mgmt_if.yaml <<EOF
        search:
        - $new_dns_search
EOF
    fi
  fi

  if [ -n "$new_gtwy" ]; then
    cat >> $working_dir/10-static-$mgmt_if.yaml <<EOF
      routes:
      - to: default
        via: $new_gtwy
EOF
  fi

  cat >> $working_dir/10-static-$mgmt_if.yaml <<EOF
  version: 2
EOF

  echo "Updating permissions..."
  chmod 600 $working_dir/10-static-$mgmt_if.yaml

  echo "Backing up original and replacing with new netplan file..."
  mkdir -p $working_dir/netplan_backup
  for file in /etc/netplan/*; do
    if [ -f "$file" ]; then
      filename=$(basename "$file")
      mv "$file" "$working_dir/netplan_backup/${filename}_$timestamp"
    fi
  done
  rm /etc/netplan/* &> /dev/null
  mv $working_dir/10-static-$mgmt_if.yaml /etc/netplan/10-static-$mgmt_if.yaml

}
