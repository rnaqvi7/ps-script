#!/bin/bash

# This script contains functions for preparing the NativeEdge Orchestrator container images for deployment

function check_harbor_registry_project () {
  if [[ $HARBOR_REGISTRY == false ]]; then
    echo "Registry is not Harbor, skipping registry project check..."
    return
  fi

  echo "Checking for harbor registry project..."
  # Check if harbor project defined in .config exists
  local reg_project_check1=$(curl -s -u "$REGISTRY_USERNAME:$REGISTRY_PASSWORD" "https://$REGISTRY_FQDN:$REGISTRY_PORT/api/v2.0/projects?name=$REGISTRY_PROJECT_NAME" | grep -o '"name":"'$REGISTRY_PROJECT_NAME'"' | awk -F':' '{print $2}' | tr -d '"')

  if [[ $reg_project_check1 == $REGISTRY_PROJECT_NAME ]]; then
    echo "Project $REGISTRY_PROJECT_NAME already exists"
  else
    # If project does not exist, create it
    echo "Project $REGISTRY_PROJECT_NAME does not exist, creating..."
    curl -X POST -H "Content-Type: application/json" -u "$REGISTRY_USERNAME:$REGISTRY_PASSWORD" -k -d "{ \"project_name\": \"$REGISTRY_PROJECT_NAME\", \"public\": false }" "https://$REGISTRY_FQDN:$REGISTRY_PORT/api/v2.0/projects"
  fi

  # Verify project creation was successful
  local reg_project_check2=$(curl -s -u "$REGISTRY_USERNAME:$REGISTRY_PASSWORD" "https://$REGISTRY_FQDN:$REGISTRY_PORT/api/v2.0/projects?name=$REGISTRY_PROJECT_NAME" | grep -o '"name":"'$REGISTRY_PROJECT_NAME'"' | awk -F':' '{print $2}' | tr -d '"')

  if [[ $reg_project_check2 == $REGISTRY_PROJECT_NAME ]]; then
    echo "Project $REGISTRY_PROJECT_NAME verified successfully"
  else
    echo "Project $REGISTRY_PROJECT_NAME creation failed.. please add it manually and try again"
    exit 1
  fi
}


function download_orchestrator_bundle () {
  echo "### NativeEdge Orchestrator bundle download started ###"
  if [[ $DOWNLOAD_BUNDLE == true ]]; then
    if [[ -f $base_dir/data/nativeedge/bundle/$BUNDLE_FILENAME ]]; then
      file $base_dir/data/nativeedge/bundle/$BUNDLE_FILENAME
      echo "Bundle already exists, skipping download..."
    else  
      echo "Downloading orchestrator bundle..."
      mkdir -p $base_dir/data/nativeedge/bundle
      wget --no-check-certificate --user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3" -O $base_dir/data/nativeedge/bundle/$BUNDLE_FILENAME $BUNDLE_URL
    fi
  else
    echo "DOWNLOAD_BUNDLE=$DOWNLOAD_BUNDLE, skipping download..."
  fi
}

function extract_orchestrator_bundle () {
  if [[ -d $base_dir/data/nativeedge/install/.resources ]]; then
    echo "Bundles already extracted..."
  else
    if [[ -f $base_dir/data/nativeedge/bundle/$BUNDLE_FILENAME ]]; then
      echo "Extracting NativeEdge Orchestrator bundle..."
      if [[ $DEV_BUILD == false ]]; then
        unzip $base_dir/data/nativeedge/bundle/$BUNDLE_FILENAME -d $base_dir/data/nativeedge/bundle/
        for file in "$base_dir/data/nativeedge/bundle/"*-*.zip; do
          unzip "$file" -d "$base_dir/data/nativeedge/install"
        done
      else
        unzip $base_dir/data/nativeedge/bundle/$BUNDLE_FILENAME -d $base_dir/data/nativeedge/install
      fi
    else
      echo "Bundle not found. upload bundle to the data/nativeedge/bundle directory and try again..."
      exit 0
    fi
  fi
}


function add_images_loader () {
  # UNUSED FUNCTION
  if [[ $SKIP_IMAGES == false ]]; then
    echo "Installing eo-images-loader container..."
    docker load -i $base_dir/data/nativeedge/install/.resources/eo-images-loader.tar.gz
    docker images
  else
    echo "SKIP_IMAGES is set to true, Skipping eo-images-loader container install..."
  fi
}

function run_images_loader () {
  # UNUSED FUNCTION
  if [[ $SKIP_IMAGES == false ]]; then
    echo "Running eo-images-loader container..."
    local images_loader_tag=$(docker images | grep eo-images-loader | awk '{print $2}')
    docker run -d --name image_loader --privileged --network=host -m 4g --cpus=4 \
      -e LOCAL_REGISTRY_URL="$REGISTRY_FQDN:$REGISTRY_PORT/$REGISTRY_PROJECT_NAME" \
      -e LOCAL_REGISTRY_USERNAME="$REGISTRY_USERNAME" \
      -e LOCAL_REGISTRY_PW="$REGISTRY_PASSWORD" \
      -e NO_OF_WORKERS_TO_PUSH_IMAGE="4" \
      -v "/usr/local/share/ca-certificates/$REGISTRY_CERT_FILENAME":/etc/ssl/certs/ca.pem \
      hzp/eo-images-loader:$images_loader_tag
  else
    echo "SKIP_IMAGES is set to true, Skipping eo-images-loader container run..."
  fi
}

function helm_install_neo () {
  if [[ $INSTALL_FROM_CATALOG == true ]]; then
    if [[  $EO_VERISON == "3.2" ]]; then
      echo "Unsupported version specified in .config file: $EO_VERISON"
      exit 1
    fi
    echo "Install from catalog is set to $INSTALL_FROM_CATALOG"
    kubectl create namespace $EO_NAMESPACE && kubectl label namespace $EO_NAMESPACE hzp.iam.webhook/active="true" --overwrite
    echo "##################"
    echo "### NativeEdge Orchestrator will be installed with the following parameters:"
    echo "### Orchestrator IP/FQDN: $EO_FQDN"
    echo "### Orchestrator Namespace: $EO_NAMESPACE"
    echo "##################"
    echo "Run this command to install NativeEdge Orchestrator:"
    echo "sudo helm upgrade --install native-edge-orchestrator oci://$HELM_INSTALL_URL --version $HELM_INSTALL_CHART_VERSION -n $EO_NAMESPACE --set global.ingress.fqdn=$EO_FQDN --wait --timeout 60m"
    echo ""
    echo "########"
    echo "Once the helm upgrade is complete, run the following command to gather the default administrator password for the NativeEdge Web UI:"
    echo "kubectl -n $EO_NAMESPACE get secret keycloak-secret -o jsonpath="{.data.security-admin-usr-pwd}" | base64 --decode && echo"
    echo "########"
    echo ""
    exit 0
  else
    return 0
  fi
}

function install_neo_deploy_script () {
  if [[ $EO_VERSION == "3.0" ]]; then
    chmod +x $base_dir/data/nativeedge/install/deploy.sh
    echo "Run this command to install NativeEdge Orchestrator v3.0:"
    echo "sudo data/nativeedge/install/deploy.sh SKIP_IMAGES_LOADER=$SKIP_IMAGES EO_HOST=$EO_FQDN IMAGE_REG_URL=$REGISTRY_FQDN:$REGISTRY_PORT/$REGISTRY_PROJECT_NAME IMAGE_REG_USERNAME=$REGISTRY_USERNAME IMAGE_REG_PASSWORD=$REGISTRY_PASSWORD REGISTRY_CERT_FILE_PATH=/usr/local/share/ca-certificates/$REGISTRY_CERT_FILENAME"
  elif [[ $EO_VERSION == "3.1" ]]; then
    chmod +x $base_dir/data/nativeedge/install/install-upgrade.sh
    kubectl create namespace $EO_NAMESPACE && kubectl label namespace $EO_NAMESPACE hzp.iam.webhook/active="true" --overwrite
    echo "Run this command to install NativeEdge Orchestrator v3.1:"
    echo "sudo data/nativeedge/install/install-upgrade.sh SKIP_IMAGES_LOADER=$SKIP_IMAGES NAMESPACE=$EO_NAMESPACE EO_HOST=$EO_FQDN IMAGE_REG_URL=$REGISTRY_FQDN:$REGISTRY_PORT/$REGISTRY_PROJECT_NAME IMAGE_REG_USERNAME=$REGISTRY_USERNAME IMAGE_REG_PASSWORD=$REGISTRY_PASSWORD REGISTRY_CERT_FILE_PATH=/usr/local/share/ca-certificates/$REGISTRY_CERT_FILENAME"
  elif [[ $EO_VERSION == "3.2" ]]; then
    chmod +x $base_dir/data/nativeedge/install/install-upgrade.sh
    echo "Run this command to install Dell Automation Platform Portal and Orchestrator:"
    echo "sudo data/nativeedge/install/install-upgrade.sh EO_HOST=$EO_FQDN IMAGE_REG_URL=$REGISTRY_FQDN:$REGISTRY_PORT/$REGISTRY_PROJECT_NAME IMAGE_REG_USERNAME=$REGISTRY_USERNAME IMAGE_REG_PASSWORD=$REGISTRY_PASSWORD SKIP_IMAGES_LOADER=$SKIP_IMAGES REGISTRY_CERT_FILE_PATH=/usr/local/share/ca-certificates/$REGISTRY_CERT_FILENAME NAMESPACE=$EO_NAMESPACE PORTAL_NAMESPACE=$PORTAL_NAMESPACE PORTAL_COOKIE_DOMAIN=$PORTAL_COOKIE_DOMAIN PORTAL_INGRESS_CLASS_NAME=$PORTAL_INGRESS_CLASS_NAME PORTAL_HOST=$PORTAL_FQDN ORG_NAME=$ORG_NAME ORG_DESC=$ORG_DESC FIRST_NAME=$FIRST_NAME LAST_NAME=$LAST_NAME USERNAME=$USERNAME EMAIL=$EMAIL"
  else
    echo "Unsupported version specified in .config file: $EO_VERSION"
  fi
}

function get_defaul_credentials () {
  # UNUSED FUNCTION
  echo "Getting default credentials..."
}

function verify_neo_install () {
  # UNUSED FUNCTION
  echo "Verifying NativeEdge Orchestrator install..."
}

function cleanup_orchestrator_bundle () {
  # UNUSED FUNCTION
  echo "Cleaning up temp bundle files..."
}

