#!/bin/bash

install_unzip_jq () {
  if ! command -v unzip &> /dev/null || ! command -v jq &> /dev/null; then
    echo "Installing unzip and jq..."
    if [[ $AIRGAPPED == "true" ]]; then
      local working_dir="$base_dir/data/unzip_jq/packages"
      local source_list_file="/etc/apt/sources.list.d/unzip_jq.list"
      create_local_repo
    fi
      DEBIAN_FRONTEND=noninteractive apt-get -y install unzip jq 2> /dev/null
  else
      echo "unzip is already installed, continuing..."
  fi
}