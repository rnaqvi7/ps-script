#!/bin/bash

# Copyright (c) 2025 Dell Inc. or its subsidiaries. All Rights Reserved.
#
# This software contains the intellectual property of Dell Inc. or is licensed to Dell Inc. from third parties.
# Use of this software and the intellectual property contained therein is expressly limited to the terms and
# conditions of the License Agreement under which it is provided by or on behalf of Dell Inc. or its subsidiaries.

version="0.9-beta"

# Default values for the arguments
minify_flag=false
keepfiles_flag=false
full_syslog=false

usage() {
  echo "Usage: $(basename "$0") [OPTIONS]"
  echo "  -s: 5m: Will collect data since the last 5 minutes"
  echo "  -m: minify: exclude system and journal ctl"
  echo "  -k: keep logs: keeping all logs in unarchived state"
  echo "  -f: grab older syslog(don't use with minify (-m) flag."
  echo "  -h: Show this help message"
  echo "  -v: Show current version"
  echo
  copyright
}

copyright() {
  echo "Copyright (c) 2024 Dell Inc. or its subsidiaries. All Rights Reserved.
This software contains the intellectual property of Dell Inc. or is licensed to Dell Inc. from third parties.
Use of this software and the intellectual property contained therein is expressly limited to the terms and
conditions of the License Agreement under which it is provided by or on behalf of Dell Inc. or its subsidiaries."
}

showversion() {
  echo "NativeEdge Orchestrator logs bundle collection tool, version: $version"
  echo
}

display_namespaces() {
  local nss=("$@")
  for ns in "${nss[@]}"; do
    echo "- $ns"
  done
}

check_package() {
  if [ -f /etc/redhat-release ]; then
    rpm -q "$1"
  else
    # assuming Debian/Ubuntu in case it's not RHEL
    dpkg-query -l "$1"
  fi
}

while getopts ":s:mkfhv" opt; do
  case $opt in
    s)
      SINCE_VALUE="$OPTARG" # Argument after -s is stored in since_value
      ;;
    m)
      minify_flag=true # Set the minify_flag to true if -a is present
      ;;
    v)
      showversion # show the version
      copyright
      exit 0
      ;;
    f)
      ## getting older syslog as well
      full_syslog=true
      ;;
    k)
      keepfiles_flag=true # Set the keepfiles_flag to true
      ;;
    h)
      usage
      exit 0
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;
    :)
      echo "Option -$OPTARG requires an argument." >&2
      exit 1
      ;;
  esac
done

# The argument index is now at the next argument after the options
shift $((OPTIND - 1))

ROOT_OUTPUT_DIR="/tmp"
DATE_TAG=$(date +"%FT%H-%M-%S.%3N")
OUTPUT_DIR_NAME="native_edge_eo-logs_$(kubectl config current-context)_$DATE_TAG"
OUTPUT_DIR="${ROOT_OUTPUT_DIR}/${OUTPUT_DIR_NAME}"
EXTENSION="log"
FREESPACE="$(df -H /tmp/ | awk 'NR==2 {print $4}')"

showversion

namespaces=("hzp" "kube-system" "istio-system" "knative-eventing" "knative-serving" "longhorn-system") 
hzp_ns="hzp"

namespaces_exists=$(kubectl get namespaces -o jsonpath='{.items[*].metadata.name}')
echo "Available namespaces:"
display_namespaces $namespaces_exists

if echo "$namespaces_exists" | grep -qw "$hzp_ns"; then
  echo "Namespace '$hzp_ns' found. Logs will be collected from following namespaces:"
  display_namespaces "${namespaces[@]}"
else
  echo "Warning: Namespace '$hzp_ns' not found."
  read -p "Please enter the namespace containing the 'nativeedge' containers: " user_ns

  # Validate user-entered namespace
  namespaces+=("$user_ns")
  hzp_ns="$user_ns"
  echo "Namespace '$user_ns' added. Logs will be collected from following namespaces:"
  display_namespaces "${namespaces[@]}"
fi

echo "This script will access your local k3s(k8s) secrets (secret values are not going to be printed)."
echo "This script will collect all logs from all pods in NativeEdge-controlled namespaces and archive it in tarball."
echo "Please press \"y\" if you agree with this."
echo "You have ${FREESPACE} available on your storage. Consider that logs may require to have more that 1Gb of free space."
read -p "Do you wish to proceed? (y/n) " yn
case $yn in
  [Yy]* ) echo "collecting logs...";;
  [Nn]* ) exit;;
  * ) echo "default considered as \"No\", enter y if you wish to proceed"; exit;;
esac

echo "Using output dir $OUTPUT_DIR"
mkdir "$OUTPUT_DIR"

capturelogs () {
  FILENAME="${OUTPUT_DIR}/pods.describe"
  kubectl get pods -A > "$FILENAME"

  # Get all pod logs and describe
  for n in "${namespaces[@]}"; do 
    kubectl get po -n "$n" --no-headers | while read -r line; do
      NAMESPACE=$n
      POD_NAME=$(echo "$line" | awk '{print $1}')
      mkdir -p "${OUTPUT_DIR}/${NAMESPACE}/${POD_NAME}"
      FILENAME="${OUTPUT_DIR}/${NAMESPACE}/${POD_NAME}/${POD_NAME}.describe"
      kubectl describe pod -n "$NAMESPACE" "$POD_NAME" > "$FILENAME"
      for CONTAINER in $(kubectl get pods "$POD_NAME" -n "$NAMESPACE"  -o jsonpath="{.spec.initContainers[*].name}"); do
        FILENAME_PREFIX="${OUTPUT_DIR}/${NAMESPACE}/${POD_NAME}/${POD_NAME}.${CONTAINER}"
        FILENAME="${FILENAME_PREFIX}.init.${EXTENSION}"
        echo "$FILENAME"
        kubectl logs -n "$NAMESPACE" "$POD_NAME" -c "$CONTAINER" > "$FILENAME"
      done
      for CONTAINER in $(kubectl get po -n "$NAMESPACE" "$POD_NAME" -o jsonpath="{.spec.containers[*].name}"); do
        FILENAME_PREFIX="${OUTPUT_DIR}/${NAMESPACE}/${POD_NAME}/${CONTAINER}"
        FILENAME="${FILENAME_PREFIX}.current.${EXTENSION}"
        echo "$FILENAME"
        if [ -z $SINCE_VALUE ]; then
          kubectl logs -n "$NAMESPACE" "$POD_NAME" "$CONTAINER" > "$FILENAME"
        else
          kubectl logs -n "$NAMESPACE" --since=$SINCE_VALUE "$POD_NAME" "$CONTAINER" > "$FILENAME"
        fi
        FILENAME="${FILENAME_PREFIX}.previous.${EXTENSION}"
        echo "$FILENAME"
        kubectl logs -p -n "$NAMESPACE" "$POD_NAME" "$CONTAINER" > "$FILENAME" 2> /dev/null
      done
    done
  done

  # Dump deployment logs

  # Define the output file name
  FILENAME="${OUTPUT_DIR}/deployment.log"

  echo "capturing deployment logs"

  # Extract the PostgreSQL password from the Kubernetes secret
  pgpassword=$(kubectl -n ${hzp_ns} get secret postgres-secret -o jsonpath='{.data.fusion_db-password}' | base64 -d)

  # Execute the SQL command using kubectl exec
  kubectl -n ${hzp_ns} exec postgres-0 -- env PGPASSWORD=$pgpassword psql fusion_db -U fusion_db -h 127.0.0.1 -c \
    'copy (select l.*, e.id as execution_id, d.id as deployment_id from logs l left outer join executions e on l._execution_fk = e._storage_id left outer join deployments d on e._deployment_fk = d._storage_id) to stdout with (format csv, header)' > "$FILENAME"

  if [ $? -ne 0 ]; then
    echo "trying baobab query... If you see error in both, please check pods/cluster health"
    kubectl -n ${hzp_ns} exec postgres-0 -- env PGPASSWORD=$pgpassword psql fusion_db -U fusion_db -h 127.0.0.1 -c \
      'copy (select l.*, e.id as execution_id, d.id as deployment_id from logs l left outer join executions e on l._execution_fk = e._storage_id left outer join deployments d on e.deployment_id = d.id) to stdout with (format csv, header)' >> "$FILENAME"
    if [ $? -eq 0 ]; then
      echo "successfully captured deployment logs to $FILENAME"
    else
      echo "there was an error capturing deployment logs, please check pods/cluster health ($FILENAME)"
    fi
  fi

  echo "capturing deployment logs completed: $FILENAME"

  # Dump all events
  FILENAME="${OUTPUT_DIR}/events.log"
  kubectl get events -A > "$FILENAME"

  # Dump jobs and cronjobs
  FILENAME="${OUTPUT_DIR}/jobs.log"
  kubectl get jobs -n ${hzp_ns} -o wide > "$FILENAME"
  FILENAME="${OUTPUT_DIR}/cronjobs.log"
  kubectl get cronjobs -n ${hzp_ns} -o wide > "$FILENAME"
  FILENAME="${OUTPUT_DIR}/services.log"
  kubectl get svc -A -o wide > "$FILENAME"
  FILENAME="${OUTPUT_DIR}/nodes.log"
  kubectl get nodes -A -o wide > "$FILENAME"
  FILENAME="${OUTPUT_DIR}/sysctlconf.log"
  sysctl -a > "$FILENAME"

  # getting major version information
  FILENAME="${OUTPUT_DIR}/eoversion.log"
  kubectl get eo -A > "$FILENAME"

  # getting longhorn-related configuration information
  FILENAME="${OUTPUT_DIR}/longhorn-preflight.log"
  systemctl status multipathd >> "$FILENAME"
  echo "----------------" >> "$FILENAME"
  systemctl status iscsid >> "$FILENAME"
  echo "----------------" >> "$FILENAME"
  echo "multipath.conf:" >> "$FILENAME"
  cat /etc/multipath.conf >> "$FILENAME"
  echo "----------------" >> "$FILENAME"
  check_package nfs-common >> "$FILENAME"

  # getting helm releases manifest
  echo "getting hr"
  FILENAME="${OUTPUT_DIR}/eohelmreleases.log"
  kubectl get hr -n $hzp_ns -oyaml > "$FILENAME"
  echo "------------------" >> "$FILENAME"
  kubectl get hr -n $hzp_ns >> "$FILENAME"

  # getting pv and pvc
  echo "getting storageinfo"
  FILENAME="${OUTPUT_DIR}/storages.log"
  kubectl get pv -owide > "$FILENAME"
  echo "-------PVC--------" >> "$FILENAME"
  kubectl get pvc -owide -n $hzp_ns >> "$FILENAME"
  echo "-------VOLUMES--------" >> "$FILENAME"
  kubectl get volumes --namespace longhorn-system -owide >> $FILENAME
  echo "------HELM SETTINGS-----" >> "$FILENAME"
  helm get values longhorn -n longhorn-system --all >> $FILENAME


  # repository accessiblity
  FILENAME="${OUTPUT_DIR}/repository-accessibility.log"

  repourl="$(kubectl get secret eo-registry-secret -n $hzp_ns -o 'go-template={{index .data "repo.url"}}' | base64 --decode)"
  # leaving the part before '/' char
  repourl="${repourl%/*/}"
  # echoing address to save it into capture.log
  echo "repourl=\"$repourl\""

  curl "https://${repourl}" -o "$FILENAME"
  echo "capturing harbor curl response completed"

  # Extract k3s config
  echo "capturing k3s config..."
  cp /etc/systemd/system/k3s.service ${OUTPUT_DIR}/
  cp /etc/systemd/system/k3s.service.env ${OUTPUT_DIR}/
  echo "capturting k3s config completed"

  # Extract k8s versions + containerd
  FILENAME="${OUTPUT_DIR}/k8sversions.log"
  kubelet --version > "$FILENAME"
  kubeadm version >> "$FILENAME"

  # K8s config for Debian/Ubuntu
  cp /etc/default/kubelet ${OUTPUT_DIR}/
  cp /etc/systemd/system/kubelet.service ${OUTPUT_DIR}/
  cp /var/lib/kubelet/config.yaml ${OUTPUT_DIR}/
  cp /etc/kubernetes/kubeadm-config.yaml ${OUTPUT_DIR}/

  #kubelet config for RHEL (changed name to not overwrite the file)
  cp /etc/sysconfig/kubelet ${OUTPUT_DIR}/kubelet.rhel

  echo "getting maxPods setting..."
  FILENAME="${OUTPUT_DIR}/nodes.describe.log"
  for K_NODE in $(kubectl get nodes --no-headers -o name); do
    echo "maxpod in $K_NODE: $(kubectl describe $K_NODE | grep pods | awk  'NR==1 {print $2}' | tr -d ' ')"
    kubectl describe $K_NODE >> "$FILENAME"
  done

  if ! $minify_flag; then
    # Dump journalctl
    echo "capturing journalctl log requested..."
    FILENAME="${OUTPUT_DIR}/journalctl.log"
    journalctl > "$FILENAME"
    echo "capturing journalctl log completed: $FILENAME"
    echo "capturing systemlog requested..."
    FILENAME="${OUTPUT_DIR}/syslog"
    cp /var/log/syslog $FILENAME
    if $full_syslog; then
      echo "capturing full systemlog requested..."
      cp /var/log/syslog.* "${OUTPUT_DIR}/" 
    fi
    echo "capturing systemlog completed: $FILENAME"

  fi  
  # Dump CoreDNS config
  FILENAME="${OUTPUT_DIR}/coredns.config"
  kubectl get configmap coredns -n kube-system -o yaml > "$FILENAME"
}

CAPTUREOUTFILENAME="${OUTPUT_DIR}/capture.log" 
capturelogs 2>&1 | tee -a "$CAPTUREOUTFILENAME"

FILENAME="${OUTPUT_DIR}/eoservicetag.log"
# Extract the PostgreSQL hzp-init user password from the Kubernetes secret
pgsecret=$(kubectl -n ${hzp_ns} get secret postgres-secret -o jsonpath="{.data.hzp_eo_initialization_svc-password}" | base64 --decode)

SERVICETAG=$(kubectl exec postgres-0 -n ${hzp_ns} -- sh -c "export PGPASSWORD='${pgsecret}' && psql -U hzp_eo_initialization_svc -h 127.0.0.1 -d hzp_eo_initialization_svc -c 'SELECT service_tag FROM eo_license';" | xargs | awk '{print $3}')
echo "$SERVICETAG" > "$FILENAME"
echo "capturing service tag completed"

echo

captureevents () {
  # Configurable parameters
  idx_name="app-logs-2025"
  PAGE_SIZE=1000
  OUTPUT_FILE="$OUTPUT_DIR/event-logs.json"
  CERT_PATH="/opensearch/opensearch/config/certs/node1.crt"
  KEY_PATH="/opensearch/opensearch/config/certs/node1.key"
  CA_CERT_PATH="/opensearch/opensearch/config/certs/ca.crt"
  OPENSEARCH_URL="https://localhost:9200"

  echo "capturing EO events...."

  # Ask if the user wants to filter by date range
  echo "Do you want to filter by date range?"
  read -p "If not, all events will be collected(y/n): " USE_DATE_FILTER

  if [[ "$USE_DATE_FILTER" == "y" ]]; then
    read -p "Enter start date (YYYY-MM-DD): " FROM_DATE
    read -p "Enter end date (YYYY-MM-DD): " TO_DATE

    DATE_FILTER=", \"query\": { 
      \"range\": { 
        \"timestamp\": { 
          \"gte\": \"$FROM_DATE\", 
          \"lte\": \"$TO_DATE\",
          \"format\": \"yyyy-MM-dd\"
        }
      }
    }"
  else
    DATE_FILTER=""
  fi

  echo -e "Date filter set to the:\n$DATE_FILTER"
  
  # First checking the indices inside eo-management
  echo "Checking the index is present in eo-management..."
  kubectl exec eo-management-opensearch-0 -n $hzp_ns -c opensearch -- curl -X GET "https://localhost:9200/_cat/indices?v" \
          --cacert "$CA_CERT_PATH" \
          --cert "$CERT_PATH" \
          --key "$KEY_PATH" --insecure | grep $idx_name

  if [ $? -ne 0 ]; then
    echo "Index $idx_name not found in eo-management, exiting"
    return 1
  fi

  # Get the total count of records
  if [[ "$USE_DATE_FILTER" == "y" ]]; then
    COUNT_QUERY="{\"query\": {\"range\": {\"timestamp\": {\"gte\": \"$FROM_DATE\", \"lte\": \"$TO_DATE\", \"format\": \"yyyy-MM-dd\"}}}}"
  else
    COUNT_QUERY="{\"query\": {\"match_all\": {}}}"
  fi

  TOTAL_RECORDS=$(kubectl exec eo-management-opensearch-0 -n $hzp_ns -c opensearch -- curl -s -X GET "$OPENSEARCH_URL/$idx_name/_count" \
    -H "Content-Type: application/json" \
    --cacert "$CA_CERT_PATH" \
    --cert "$CERT_PATH" \
    --key "$KEY_PATH" \
    --insecure \
    -d "$COUNT_QUERY" | jq '.count')

  echo "TOTAL_RECORDS=$TOTAL_RECORDS"

  # Initial search request to get the first batch and scroll ID
  RESPONSE=$(kubectl exec eo-management-opensearch-0 -n $hzp_ns -c opensearch -- curl -s -X POST "$OPENSEARCH_URL/$idx_name/_search?scroll=1m" \
    -H "Content-Type: application/json" \
    --cacert "$CA_CERT_PATH" \
    --cert "$CERT_PATH" \
    --key "$KEY_PATH" \
    --insecure \
    -d "{
      \"size\": 1000,
      \"sort\": [{\"timestamp\": \"desc\"}]
      $DATE_FILTER
    }")

  # Extract the initial scroll ID
  SCROLL_ID=$(echo "$RESPONSE" | jq -r '._scroll_id')
  echo "SCROLL_ID=$SCROLL_ID"

  # Extract and save the first batch of documents
  echo "$RESPONSE" | jq '.hits.hits' >> "$OUTPUT_FILE"

  while [ "$SCROLL_ID" != "null" ]; do
    # Get the next batch using the scroll ID
    RESPONSE=$(kubectl exec eo-management-opensearch-0 -n ${hzp_ns} -c opensearch -- curl -s -X POST "$OPENSEARCH_URL/_search/scroll" \
      -H "Content-Type: application/json" \
      --cacert "$CA_CERT_PATH" \
      --cert "$CERT_PATH" \
      --key "$KEY_PATH" \
      --insecure \
      -d "{\"scroll\": \"1m\", \"scroll_id\": \"$SCROLL_ID\"}")

    # Extract new scroll ID
    SCROLL_ID=$(echo "$RESPONSE" | jq -r '._scroll_id')
    HIT_COUNT=$(echo "$RESPONSE" | jq '.hits.hits | length')

    # Extract and append new batch of documents
    echo "$RESPONSE" | jq '.hits.hits' >> "$OUTPUT_FILE"

    # Break if no more results
    if [ "$(echo "$RESPONSE" | jq '.hits.hits | length')" -eq 0 ]; then
            break;
    fi
    TOTAL_FETCHED=$((TOTAL_FETCHED + HIT_COUNT))

    echo "Progress: $TOTAL_FETCHED / $TOTAL_RECORDS records fetched..."
  done

  # Cleanup: Delete the scroll context
  kubectl exec eo-management-opensearch-0 -n $hzp_ns -c opensearch -- curl -s -X DELETE "$OPENSEARCH_URL/_search/scroll" \
    -H "Content-Type: application/json" \
    --cacert "$CA_CERT_PATH" \
    --cert "$CERT_PATH" \
    --key "$KEY_PATH" \
    --insecure \
    -d "{\"scroll_id\": \"$SCROLL_ID\"}" > /dev/null

  echo "All logs saved to $OUTPUT_FILE"
}

# Ask if the user wants to filter by date range
echo "Do you want to collect the EO events (WARNING: this may require significant space on disk)?"
read -p "If not, events collection will be skipped(y/n): " COLLECT_EVENTS
if [[ "$COLLECT_EVENTS" == "y" ]]; then
  CAPTUREEVENTSSTATUS="${OUTPUT_DIR}/capture-events-flow.log" 
  captureevents 2>&1 | tee -a "$CAPTUREEVENTSSTATUS"
else
  echo "user has opted not to collect the events" | tee -a  "$OUTPUT_DIR/event-logs.json"
fi

CWD=$(pwd)
cd $ROOT_OUTPUT_DIR || exit 1

TARBALL_FILE_NAME="${OUTPUT_DIR_NAME}.tar.gz"
# If service tag is set we overriding file name to use service tag in it
if [[ ${#SERVICETAG} -eq 7 ]]; then
  TARBALL_FILE_NAME="native_edge_eo-logs_${SERVICETAG}_${DATE_TAG}.tar.gz"
fi

echo "saving to $TARBALL_FILE_NAME"
  
tar -czvf "./${TARBALL_FILE_NAME}" "./${OUTPUT_DIR_NAME}"
mv "./${TARBALL_FILE_NAME}" "$OUTPUT_DIR"

if ! $keepfiles_flag; then
  echo "cleaning up..."
  find "${OUTPUT_DIR}" -maxdepth 1 -mindepth 1 | grep -v "${TARBALL_FILE_NAME}" | xargs rm -rf
fi

cd "$CWD" || exit 1