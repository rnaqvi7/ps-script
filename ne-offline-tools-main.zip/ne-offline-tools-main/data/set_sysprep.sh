#!/bin/bash

# This contains functions for setting the host to be template-ready
# Erasing the machine-id will prevent duplicate issues when cloning the VM for template purposes

function set_sysprep {
    rm /etc/machine-id
    touch /etc/machine-id
    truncate -s 0 /etc/machine-id
}
