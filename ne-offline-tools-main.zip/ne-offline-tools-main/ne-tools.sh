#!/bin/bash

# Copyright (c) 2025 Dell Inc. or its subsidiaries. All Rights Reserved.
#
# This software contains the intellectual property of Dell Inc. or is licensed to Dell Inc. from third parties.
# Use of this software and the intellectual property contained therein is expressly limited to the terms and
# conditions of the License Agreement under which it is provided by or on behalf of Dell Inc. or its subsidiaries.

base_dir=$(pwd)
base_dir_name=$(basename $base_dir)
logs_dir="$base_dir/data/logs"
OS_DESCRIPTION=$(lsb_release -d)
OS_RELEASE_VERSION=$(lsb_release -ds |tail -1)
OS_RELEASE_SHORT=$(lsb_release -rs |tail -1)
mgmt_ip=$(hostname -I | awk '{print $1}')
mgmt_if=$(ip a |grep "$(hostname -I |awk '{print $1}')" | awk '{print $NF}')

#sources
set +H
source data/.env
source .config
source data/offline_prep.sh
source data/k8s/install_k8s.sh
source data/host_net/hostNetCtl.sh
source data/registry/install_harbor.sh
source data/nginx/install_nginx.sh
source data/docker/install_docker.sh
source data/unzip_jq/install_unzip_jq.sh
source data/set_sysprep.sh
source data/neo_pre_check.sh
source data/nativeedge/install_neo.sh
source data/host_net/set_ntp.sh

#logs
offline_prep_log="$logs_dir/offline-prep.log"
set_hostname_log="$logs_dir/set-hostname.log"
set_static_ip_log="$logs_dir/set-static-ip.log"
install_registry_server_log="$logs_dir/install-registry-server.log"
install_artifact_server_log="$logs_dir/install-artifact-server.log"
install_k8s_log="$logs_dir/install-k8s.log"
neo_pre_check_log="$logs_dir/neo-pre-check.log"
set_sysprep_log="$logs_dir/set-sysprep.log"
common_log="$logs_dir/common.log"
neo_install_log="$logs_dir/neo-install.log"

function check_root_privileges() {
  if [[ $EUID != 0 ]]; then
    echo "This script must be run as root."
    exit 1
  fi
}
function help {
  echo "########################################################################"
  echo "###                     NativeEdge Offline-Tools                     ###"
  echo "### Environmental variables defined in data/.env & .config           ###"
  echo "### Log output is stored in data/logs/                               ###"
  echo "########################################################################"
  echo "Usage: $0 [--parameter]"
  echo ""
  echo "[Parameters]              | [Description]"                   
  echo "--help                    | Display this help message"
  echo "--offline-prep            | Prepares an offline bundle for this host's OS version"
  echo "--set-hostname            | Sets a user defined hostname for this host"
  echo "--set-static-ip           | Sets a user defined static IP for this host"
  echo "--set-ntp-servers         | Sets user defined NTP servers for this host"
  echo "--install-registry-server | Installs Harbor registry using SSL"
  echo "--install-artifact-server | Installs NGINX webserver using SSL"
  echo "--install-k8s             | Installs k8s and services required for NativeEdge Orchestrator"
  echo "--install-orchestrator    | Prepares NativeEdge Orchestrator bundle and provides install command"
  echo "--neo-pre-check           | Verifies NativeEdge Orchestrator deployment pre-requisites"
  echo "--add-registry-cert       | Manually installs container registry certificate"
  echo "--set-sysprep             | Sets the host to be template-ready and erases machine-id"
}

function offline_prep () {
  echo ""
  echo "Running connectivity check for offline package preparation..."
  # Loop through each URL and check reachability
  for url in "${!urls[@]}"; do
      check_url "$url" "${urls[$url]}"
  done
  # Summary of failed URLs
  if [ ${#failed_urls[@]} -ne 0 ]; then
      echo -e "\n\e[1;31mSummary of Unreachable URLs:\e[0m"
      for entry in "${failed_urls[@]}"; do
          echo -e "\e[31m- $entry\e[0m"
      done
      echo -e "\e[31mWARNING\e[0m - Offline preperation may not complete successfully"
      prompt_continue
  else
      echo -e "\n\e[1;32mAll URLs are reachable!\e[0m"
  fi
  set_prep_status
  download_orchestrator_bundle
  install_dpkg_dev
  prep_unzip_jq
  prep_nginx
  prep_docker
  prep_kube_apps
  prep_containerd
  prep_k8s_containers
  prep_helm
  install_helm
  pull_helm_charts
  prep_harbor
}

function set_hostname () {
    hostname_ctl
}

function set_static_ip () {
    static_ip_ctl
}

function install_registry_server () {
    check_offline_prep_status
    disable_ufw_if_enabled
    update_sources_list
    install_docker
    harbor_cert_gen
    harbor_cert_install
    extract_harbor
    generate_harbor_yml
    install_harbor
    create_harbor_service
    restore_sources_list
}

function install_artifact_server () {
    check_offline_prep_status
    disable_ufw_if_enabled
    update_sources_list
    nginx_check
    prepare_dirs
    nginx_cert_gen
    auth_gen
    conf_gen
    apply_server
    gen_curl_header
    restore_sources_list
}

function install_k8s () {
    check_offline_prep_status
    disable_ufw_if_enabled
    systemctl stop multipathd.socket multipathd.service
    systemctl disable multipathd.socket multipathd.service
    update_sources_list
    echo "Verifying and installing dependencies..."
    if ! command -v ctr &> /dev/null 
    then
        echo "Configuring kernel settings and containerd..."
        add_modules
        update_sysctl
        disable_swap
        install_runc
        install_containerd
        install_cni_plugins
    else
        echo "Containerd already installed..."
    fi
    echo "Checking for kubeadm, kubelet, and kubectl..."
    if ! command -v kubeadm &> /dev/null
    then
        install_kube_apps
    else
        echo "kubeadm already installed..."
    fi
    echo "Checking for container images..."
    echo "Kube"
    local kube_images=("$KUBE_METRICS_IMAGE" "$KUBE_CONTROLLER_IMAGE" "$KUBE_PROXY_IMAGE" "$KUBE_SCHEDULER_IMAGE" "$KUBE_PAUSE_IMAGE" "$KUBE_COREDNS_DIGEST_IMAGE" "$KUBE_ETCD_DIGEST_IMAGE" "$KUBE_APISERVER_DIGEST_IMAGE" "$KUBE_CONTROLLER_DIGEST_IMAGE" "$KUBE_PROXY_DIGEST_IMAGE" "$KUBE_SCHEDULER_DIGEST_IMAGE" "$KUBE_PAUSE_DIGEST_IMAGE" "$HAPROXY_IMAGE")
    check_ctr_images "${kube_images[@]}"
    if ! $found_images; then
      import_images "$base_dir/data/k8s/images/kube"
    fi
    echo "Calico"
    local calico_images=("$CALICO_CNI_IMAGE" "$CALICO_CONTROLLER_IMAGE" "$CALICO_NODE_IMAGE")
    check_ctr_images "${calico_images[@]}"
    if ! $found_images; then
      import_images "$base_dir/data/k8s/images/calico"
    fi
    echo "Longhorn"
    local longhorn_images=("$LONGHORN_BACKING_IMAGE" "$LONGHORN_ATTACHER_IMAGE" "$LONGHORN_REGISTRAR_IMAGE" "$LONGHORN_PROVISIONER_IMAGE" "$LONGHORN_RESIZER_IMAGE" "$LONGHORN_SNAPSHOTTER_IMAGE" "$LONGHORN_LIVENESSPROBE_IMAGE" "$LONGHORN_ENGINE_IMAGE" "$LONGHORN_INSTANCE_IMAGE" "$LONGHORN_MANAGER_IMAGE" "$LONGHORN_SHARE_IMAGE" "$LONGHORN_UI_IMAGE" "$LONGHORN_SUPPORT_IMAGE")
    check_ctr_images "${longhorn_images[@]}"
    if ! $found_images; then
      import_images "$base_dir/data/k8s/images/longhorn"
    fi
    echo "Metallb"
    local metallb_images=("$METALLB_CONTROLLER_IMAGE" "$METALLB_SPEAKER_IMAGE")
    check_ctr_images "${metallb_images[@]}"
    if ! $found_images; then
      import_images "$base_dir/data/k8s/images/metallb"
    fi
    echo "Container image checks complete..."
    echo "Kubernetes cluster prep completed..."
    init_k8s_singlenode
    install_helm
    apply_calico
    apply_metrics
    apply_longhorn
    apply_metallb
    if [[ $EO_VERSION == "3.2" ]]; then
      apply_haproxy
    fi
    install_docker
    install_unzip_jq
    add_reg_cert
    restart_services
    patch_tls_version
    restore_sources_list
}

function neo_pre_check () {
    run_pre_check
}

function check_prep_status () {
    echo "Checking: $working_dir"
    stat $working_dir/prep.done &> /dev/null
}

function check_offline_prep_status () {
    if [[ $OFFLINE_PREP_STATUS == true ]]; then
      echo "Offline prep flag is $OFFLINE_PREP_STATUS"
      return 0
    else
      echo "Offline prep flag is $OFFLINE_PREP_STATUS"
      echo "run --offline-prep before trying this opperation"
      exit 1
    fi
}

function create_local_repo () { 
    if check_prep_status; then
      echo "Confirmed $working_dir"
      if [ -f "$source_list_file" ]; then
        echo "Potential online repo already exists, backing it up..."
        mv $source_list_file $source_list_file.bak
      fi
      echo "Creating local repo in $working_dir..."
      echo "deb [trusted=yes] file:$working_dir ./" | tee -a $source_list_file.local.list >/dev/null
      apt-get update >> $logs_dir/common.log
    else
      echo "Packages not prepared, try running --offline-prep first."
      exit 1
    fi
}

#function to update apt-get sources for air-gapped env (reduces install time)
function update_sources_list() {
  echo "Running airgapped environment check..."
  if [[ $OS_RELEASE_SHORT == "22.04" ]]; then
    echo "Ubuntu $OS_RELEASE_SHORT detected."
    if [ -f /etc/apt/sources.list.bak ]; then
      echo "Found backup of apt-get sources. No changes needed..."
      return
    fi
    if [[ $AIRGAPPED == "true" ]]; then
      echo "AIRGAPPED flag is set to $AIRGAPPED. Updating sources..."
      # Backup the current sources.list
      echo "Creating backup of /etc/aps/sources.list..."
      cp /etc/apt/sources.list /etc/apt/sources.list.bak
      # Comment out lines containing 'ubuntu.com'
      echo "Updating /etc/apt/sources.list to exclude ubuntu.com repositories..."
      sed -i 's/^/#/' /etc/apt/sources.list
      echo "/etc/apt/sources.list has been updated."
      # Backup docker.list and kubernetes.list if they exist
      if [ -f /etc/apt/sources.list.d/docker.list ]; then
        mv /etc/apt/sources.list.d/docker.list /etc/apt/sources.list.d/docker.list.bak
      fi
      if [ -f /etc/apt/sources.list.d/kubernetes.list ]; then
        mv /etc/apt/sources.list.d/kubernetes.list /etc/apt/sources.list.d/kubernetes.list.bak
      fi
    else
      echo "AIRGAPPED flag is set to $AIRGAPPED. No changes made to /etc/apt/sources.list."
    fi
  elif [[ $OS_RELEASE_SHORT == "24.04" ]]; then
    echo "Ubuntu $OS_RELEASE_SHORT detected."
    if [ -f /etc/apt/sources.list.d/ubuntu.sources.bak ]; then
      echo "Found backup of apt-get sources. No changes needed..."
      return
    fi
    if [[ $AIRGAPPED == "true" ]]; then
      echo "AIRGAPPED flag is set to $AIRGAPPED. Updating sources..."
      # Backup the current sources.list
      echo "Creating backup of /etc/aps/sources.list.d/ubuntu.sources..."
      cp /etc/apt/sources.list.d/ubuntu.sources /etc/apt/sources.list.d/ubuntu.sources.bak
      # Comment out lines containing 'ubuntu.com'
      echo "Updating /etc/apt/sources.list.d/ubuntu.sources to exclude ubuntu.com repositories..."
      sed -i 's/^/#/' /etc/apt/sources.list.d/ubuntu.sources
      echo "/etc/apt/sources.list.d/ubuntu.sources has been updated."
      # Backup docker.list and kubernetes.list if they exist
      if [ -f /etc/apt/sources.list.d/docker.list ]; then
        mv /etc/apt/sources.list.d/docker.list /etc/apt/sources.list.d/docker.list.bak
      fi
      if [ -f /etc/apt/sources.list.d/kubernetes.list ]; then
        mv /etc/apt/sources.list.d/kubernetes.list /etc/apt/sources.list.d/kubernetes.list.bak
      fi
    else
      echo "AIRGAPPED flag is set to $AIRGAPPED. No changes made to /etc/apt/sources.list."
    fi
  else
    echo "Unsupported Ubuntu version detected.. skipping air gapped environment check."
    return
  fi
}

function restore_sources_list() {
  if [[ "$AIRGAPPED" != "true" ]]; then
    echo "Not in airgapped mode. Skipping source list restoration."
    return 0
  fi

  echo "Restoring APT source lists..."

  # Restore main sources.list if backup exists
  if [[ -f /etc/apt/sources.list.bak ]]; then
    echo "Restoring /etc/apt/sources.list..."
    cp /etc/apt/sources.list.bak /etc/apt/sources.list
    rm -f /etc/apt/sources.list.bak
  fi

  # Restore Ubuntu Deb822 sources file if backup exists
  if [[ -f /etc/apt/sources.list.d/ubuntu.sources.bak ]]; then
    echo "Restoring /etc/apt/sources.list.d/ubuntu.sources..."
    cp /etc/apt/sources.list.d/ubuntu.sources.bak /etc/apt/sources.list.d/ubuntu.sources
    rm -f /etc/apt/sources.list.d/ubuntu.sources.bak
  fi

  # List of .list files to restore from .bak
  local list_files=(
    "unzip_jq.list"
    "docker.list"
    "nginx.list"
    "kubernetes.list"
  )

  for file in "${list_files[@]}"; do
    local bak_path="/etc/apt/sources.list.d/${file}.bak"
    local original_path="/etc/apt/sources.list.d/${file}"
    local local_repo_path="/etc/apt/sources.list.d/${file}.local.list"

    if [[ -f "$local_repo_path" ]]; then
      echo "Backing up local repo $file ..."
      mv "$local_repo_path" "$local_repo_path.bak"
    fi
    if [[ -f "$bak_path" ]]; then
      echo "Restoring $file ..."
      mv "$bak_path" "$original_path"
    fi
  done

  echo "Source list restoration complete."
}

function prompt_continue() {
  while true; do
    read -p "Do you want to continue? (Y/N): " yn
    case $yn in
      [Yy]* ) echo "Continuing..."; break;;
      [Nn]* ) echo "Exiting..."; exit;;
      * ) echo "Please answer Y or N.";;
    esac
  done
}

function registry_cert_check() {
  while true; do
    read -p "Would you like to download and apply the registry certificate now? (Y/N): " regQ
    case $regQ in
        [Yy]* )
            manual_add_reg_cert
            break;;
        [Nn]* )
            echo "Skipping registry certificate...";
            break;;
        * )
            echo "Invalid choice. Enter (Y) to download and apply registry certificate or (N) to skip..."
            ;;
    esac
  done
}

# function to download and add reg cert to local store
function manual_add_reg_cert() {
  read -p "Enter URL and port of registry (i.e: registry.local.edge:443): " reg_url
  echo "Attempting to download certificate..."
  mkdir -p $base_dir/data/cert/manual
  local working_dir="$base_dir/data/cert/manual"
  local reg_basename=$(echo $reg_url | cut -d: -f1)
  local reg_port=$(echo $reg_url | cut -d: -f2)
  echo | openssl s_client -showcerts -connect $reg_url 2>/dev/null | openssl x509 > $working_dir/$reg_basename.crt
  if [ ! -f $working_dir/$reg_basename.crt ]; then
    echo "ERROR: Unable to download certificate from $reg_basename:$reg_port"
    return 1
  fi
  local confirm_pem=$(file $working_dir/$reg_basename.crt |grep -o PEM) 
  if [[ $confirm_pem == "PEM" ]]; then
    mv $working_dir/$reg_basename.crt /usr/local/share/ca-certificates/
    update-ca-certificates
    echo "Completed adding certficate for $reg_url"
    echo "updating .config with user input..."
    sed -i "s|^\(REGISTRY_FQDN=\).*|\1$reg_basename|" $base_dir/.config
    sed -i "s|^\(REGISTRY_PORT=\).*|\1$reg_port|" $base_dir/.config
    sed -i "s|^\(REGISTRY_CERT_FILENAME=\).*|\1$reg_basename.crt|" $base_dir/.config
  else
    echo "ERROR: Unable to verify certificate downloaded from $reg_url"
    echo "Ensure certificate is valid and contains registry FQDN/IP specified in $reg_url"
  fi
}

function add_reg_cert () {
  echo "Downloading and adding registry certificate from .config data..."
  mkdir -p $base_dir/data/cert
  local working_dir="$base_dir/data/cert"
  echo | openssl s_client -showcerts -connect $REGISTRY_FQDN:$REGISTRY_PORT 2>/dev/null | openssl x509 > $working_dir/$REGISTRY_CERT_FILENAME
  if [ ! -f $working_dir/$REGISTRY_CERT_FILENAME ]; then
    echo "ERROR: Unable to download certificate from $REGISTRY_FQDN:$REGISTRY_PORT"
    return 1
  fi
  local confirm_pem=$(file $working_dir/$REGISTRY_CERT_FILENAME |grep -o PEM) 
  if [[ $confirm_pem == "PEM" ]]; then
    mv $working_dir/$REGISTRY_CERT_FILENAME /usr/local/share/ca-certificates/
    update-ca-certificates
    echo "Completed adding certficate for $REGISTRY_FQDN"
  else
    echo "ERROR: Unable to verify certificate downloaded from $REGISTRY_FQDN:$REGISTRY_PORT"
    echo "Ensure certificate is valid and contains registry FQDN/IP specified in REGISTRY_FQDN value of .config"
  fi
}

function restart_services () {
  echo "Restarting services..."
  systemctl restart docker
  echo "Docker restarted..."
  sleep 3
  systemctl restart kubelet
  echo "Kubelet restarted..."
  sleep 3
  systemctl restart containerd
  echo "Containerd restarted..."
  sleep 3
}

function make_logs_dir () {
  if [ ! -d $logs_dir ]; then
    mkdir $logs_dir
  fi
}

function install_orchestrator () {
  if [[ $OFFLINE_PREP_STATUS == false ]]; then
    echo "Offline prep flag is $OFFLINE_PREP_STATUS"
    echo "run --offline-prep before trying this opperation"
    exit 1
  fi
  helm_install_neo
  check_harbor_registry_project
  download_orchestrator_bundle
  extract_orchestrator_bundle
  echo "##################"
  echo "### NativeEdge Orchestrator will be installed with the following parameters: ###"
  echo "### Orchestrator IP/FQDN: $EO_FQDN"
  echo "### Orchestrator Namespace: $EO_NAMESPACE"
  echo "### Container Registry: $REGISTRY_FQDN/$REGISTRY_PROJECT_NAME"
  echo "### Container Registry Username: $REGISTRY_USERNAME"
  echo "### Container Registry Password: $REGISTRY_PASSWORD"
  echo "### Container Registry Certificate: $REGISTRY_CERT_FILENAME"
  echo "### Skip pushing images to registry: $SKIP_IMAGES"
  echo "##################"
  install_neo_deploy_script
}

function disable_ufw_if_enabled() {
  echo "Checking UFW status..."

  if ! command -v ufw &> /dev/null; then
    echo "UFW is not installed on this system."
    return 0
  fi

  local ufw_status=$(ufw status | grep -i "Status:" | awk '{print $2}')
  local service_status=$(systemctl is-active ufw)

  if [[ "$ufw_status" == "active" || "$service_status" == "active" ]]; then
    echo "UFW is currently active. Disabling it permanently..."
    ufw disable
    systemctl stop ufw
    systemctl disable ufw
    echo "UFW has been disabled and will not start on boot."
  else
    echo "UFW is already disabled and not running."
  fi
}

#Start CLI Wrapper
make_logs_dir
while [[ $# -gt 0 ]]; do
  case "$1" in
    --help)
      help
      exit 0
      ;;
    --offline-prep)
      check_root_privileges
      echo "###############################################################################"
      echo "###  Offline preparation Started!                                           ###"
      echo "###  Creating bundle and preparing host for offline installation...         ###"
      echo "###############################################################################"
      echo "### --offline-prep SARTED ###" >> $offline_prep_log
      offline_prep
      echo "###############################################################################"
      echo "###  Offline preparation completed! Check the above output for details.     ###"
      echo "###############################################################################"
      echo "###  Run the following command to create a tar.gz bundle:                   ###"
      echo "###  cd .. && sudo tar -czvf $base_dir_name.tar.gz $base_dir_name"               
      echo "###############################################################################"
      echo "###  Host is ready for app installtion, run again with new [--parameter]    ###"
      echo "###############################################################################"
      echo "WARNING - Copying bundle to USB may wipe permissions and is not recommended!"
      echo "WARNING - This bundle will only support:"
      echo "$OS_RELEASE_VERSION"
      echo "### --offline-prep ENDED ###" >> $offline_prep_log
      exit 0
      ;;
    --set-hostname)
      check_root_privileges
      echo "#####################################################"
      echo "###  Set Hostname Started!"
      echo "#####################################################"
      echo "WARNING - This command will change the hostname of this host"
      prompt_continue
      echo "### --set-hostname SARTED ###" >> $set_hostname_log
      set_hostname
      echo "#####################################################"
      echo "###  Set Hostname Completed!"
      echo "###  Hostname: $new_hostname"
      echo "###  Reboot this host or reload shell to apply changes"
      echo "#####################################################"
      echo "### --set-hostname ENDED ###" >> $set_hostname_log
      exit 0
      ;;
    --set-static-ip)
      check_root_privileges
      echo "#######################################################################"
      echo "###  Set Static IP Started!"
      echo "#######################################################################"
      echo "WARNING - This command will change the static IP of this host"
      prompt_continue
      echo "### --set-static-ip SARTED ###" >> $set_static_ip_log
      set_static_ip
      echo "### --set-static-ip ENDED ###" >> $set_static_ip_log
      echo "######################################################################"
      echo "###  Set Satic IP Completed!"
      echo "###  /etc/netplan/10-static-$primary_interface_name.yaml"
      echo "###  Reboot this host or run 'sudo netplan apply' to apply changes"
      echo "######################################################################"
      exit 0
      ;;
    --set-ntp-servers)
      check_root_privileges
      echo "#######################################################################"
      echo "###  Set NTP Servers Started!"
      echo "#######################################################################"
      set_ntp_servers
      echo "######################################################################"
      echo "###  Set NTP Servers Completed!"
      echo "######################################################################"
      exit 0
      ;;
    --install-registry-server)
      check_root_privileges
      echo "#######################################################################"
      echo "###  Install Registry Server Started!"
      echo "###  Installing Harbor with config from .config"
      echo "#######################################################################"
      echo "### --install-regsistry-server SARTED ###" >> $install_registry_server_log
      install_registry_server
      echo "### --install-registry-server ENDED ###" >> $install_registry_server_log
      echo "#######################################################################"
      echo "###  Harbor Install Completed!"
      echo "###  Harbor Version: $HARBOR_VERSION"
      echo "###  URL: https://$mgmt_ip:$HARBOR_PORT"
      echo "###  FQDN URL: https://$REGISTRY_COMMON_NAME:$HARBOR_PORT"
      echo "###  Username: $HARBOR_USERNAME"
      echo "###  Password: $HARBOR_PASSWORD"
      echo "#######################################################################"
      exit 0
      ;;
    --install-artifact-server)
      check_root_privileges
      echo "###########################################################################"
      echo "### Installing artifact server on $mgmt_ip port $NGINX_PORT"
      echo "###########################################################################"
      echo "### --install-artifact-server SARTED ###" >> $install_artifact_server_log
      install_artifact_server
      echo "###########################################################################"
      echo "### Artifact server workflow completed! check output for details."
      echo "### URL: https://$mgmt_ip:$NGINX_PORT"
      echo "### Username: $HTUSER"
      echo "### Password: $HTPASS"
      echo "### Upload artifacts to /var/www/nginx/artifacts/"
      echo "### Download Header: curl -H \"Authorization: Basic $base64_auth_string\""
      echo "###########################################################################"
      echo "### --install-artifact-server ENDED ###" >> $install_artifact_server_log
      exit 0
      ;;
    --install-k8s)
      check_root_privileges  
      echo "###########################################################################"
      echo "### Installing Kubernetes $K8S_VERSION as a Single-Node Cluster."
      echo "###########################################################################"
      echo "### --install-k8s SARTED ###" >> $install_k8s_log
      install_k8s
      check_ntp_status
      echo "###########################################################################"
      echo "###  Kubernetes cluster workflow completed! check output for details.   ###"
      echo "###########################################################################"
      echo "###  Longhorn UI is available at http://$mgmt_ip:31000"
      echo "###  Loadbalancer IP is set to: $mgmt_ip"
      echo "###########################################################################"
      echo "###  Next, verify NativeEdge Orchestrator deployment is ready with:     ###"
      echo "###  --neo-pre-check                                                    ###"
      echo "###########################################################################"
      echo "### --install-k8s ENDED ###" >> $install_k8s_log
      exit 0
      ;;
    --neo-pre-check)
      check_root_privileges
      echo "###########################################################################"
      echo "### Running verification checks for NativeEdge Orchestrator deployment  ###"
      echo "###########################################################################"
      echo "### --neo-pre-check SARTED ###" >> $neo_pre_check_log
      neo_pre_check
      echo "### --neo-pre-check ENDED ###" >> $neo_pre_check_log
      exit 0
      ;;
    --add-registry-cert)
      check_root_privileges
      echo "###########################################################################"
      echo "### Manual install of container registry certificate"
      echo "###########################################################################"
      echo "### --install_registry_cert SARTED ###" >> $common_log
      manual_add_reg_cert
      restart_services
      echo "### --install_registry_cert ENDED ###" >> $common_log
      exit 0
      ;;
    --install-orchestrator)
      check_root_privileges
      echo "###########################################################################"
      echo "### Preparing NativeEdge Orchestrator bundle for installation"
      echo "###########################################################################"
      echo "### --install-orchestrator SARTED ###" >> $neo_install_log
      install_orchestrator
      echo "### --install-orchestrator ENDED ###" >> $neo_install_log
      exit 0
      ;;
    --set-sysprep)
      check_root_privileges
      echo "###########################################################################"
      echo "### Set sysprep started!"
      echo "### This command will set the host to be template-ready"
      echo "###########################################################################"
      echo "WARNING -- This will erase the machine-id and a new one will be generated on next boot"
      echo "WARNING -- It is recommended to run --offine-prep before this command"
      echo "WARNING -- If --install-k8s has already been run, creating a template is NOT recommended"
      prompt_continue
      echo "Setting sysprep..."
      echo "### --set-sysprep SARTED ###" >> $set_sysprep_log
      set_sysprep
      echo "### --set-sysprep ENDED ###" >> $set_sysprep_log
      echo "###########################################################################"
      echo "### Set sysprep Finshed!"
      echo "### Next, power off the machine and convert to template from hypervisor"
      echo "###########################################################################"
      exit 0
      ;;

    *)
      echo "Invalid option: $1"
      help
      exit 1
      ;;
  esac
  shift
done

help
#End CLI Wrapper
