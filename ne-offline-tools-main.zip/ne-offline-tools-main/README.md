# ne-offline-tools

NE-offline-tools is a multi-purpose toolset for setting up an enviroment to support and deploy Dell Automation Platform Portal and Orchestrator

*NOTICE* This tool is for Dell Technologies INTERNAL USE ONLY and not meant for customer use without Dell Technologies guidance and supervision

### Key Features
- Prepares an offline-bundle for air-gapped environments
- Prepared bundle may be used on a fresh installed Ubuntu host of the same OS version
- Install a Kubernetes single-node cluster
- Prepare a host with all pre-requisites for NativeEdge Orchestrator deployment
- Install a Harbor registry for hosting NativEedge containters
- Install an NGINX webserver for serving static files leveraged by NativeEdge blueprints
- Prepare a host to be "template-ready" for creating OVF, QCOW2, or VM images
- Set hostname with user input
- Set static IP with user input ( IP/CIDR, Gateway, DNS servers, DNS search domains )
- Set NTP servers with user input ( comma separated list )
- Run a pre-check to verify readiness for NativeEdge deployment
- Prepare the NativeEdge installation bundle and provide a command to deploy Dell Automation Platform

## Pre-requisites and Limitations

- This script package will only work on Ubuntu.
- Required Ubuntu version is 24.04, or 22.04 server stable LTS
- Taking regular VM Snapshots is recommened as some errors due to improper configuration may be irreversable
- This script requires internet access to create an offline bundle
- Offline bundle may then be copied to another host running the same Ubuntu LTS version in an air-gapped environment
- For air-gapped installation, the host must at minimum be configured with IP Address, Gateway IP, and DNS server for kubernetes to properly install
- Static IP is highly recommened to avoid issue with accidental IP changes on the kubernetes cluster
- For deployments using DNS and FQDN, all network and name resolution must be pre-configured
- The environment variables must be set accoring to the environment in the .config file file before running the script. the data/.env file contains advanced configuration not to be used without guidance

### Resource Requirements

Installing NativeEdge Orchestrator v3.1
- 9 CPU
- 22 GB Memory
- 700 GB storage allocated to the root '/' partition

Installing Dell Automation Platform v1.0 +
- 16 CPU
- 32 GB Memory
- 1000 GB storage allocated to the root '/' partition

Installing Artifact and Registry server
- 4 CPU
- 8 GB Memory
- 500 GB of storage allocated to the root '/' partition, more depending on ISV/Blueprint requirments

### General Guidance

1. Use a fresh install of Ubuntu Server virtual machine 
2. Run --offline-prep first before any --install parameters
3. Run --set-static-ip before --instal parameters to ensure IPs do not change after installation
4. Running --install-registry-server and --install-artifact-server is supported on the same host
4. Running --install-k8s or --install-orchestrator on the same host as the Registry and Artifact server is NOT supported

## Installation

- Download as tar.gz file from Releases > Assets 
- Upload to target Ubuntu host

## Usage

```
tar xzvf ne-offline-tools-<version>.tar.gz
cd ne-offline-tools-<version>
vi .config #Edit variables to your need, advanced variables are in data/.env
chmod +x ne-tools.sh
sudo ./ne-tools.sh
```

```
Usage: sudo ./ne-tools.sh [--parameter]

[Parameters]              | [Description]                
--help                    | Display this help message
--offline-prep            | Prepares an offline bundle for this host's OS version
--set-hostname            | Sets a user defined hostname for this host
--set-static-ip           | Sets a user defined static IP for this host
--set-ntp-servers         | Sets user defined NTP servers for this host
--install-registry-server | Installs Harbor registry using SSL
--install-artifact-server | Installs NGINX webserver using SSL
--install-k8s             | Installs k8s and services required for NativeEdge Orchestrator
--install-orchestrator    | Prepares NativeEdge Orchestrator bundle and provides install command
--neo-pre-check           | Verifies NativeEdge Orchestrator deployment pre-requisites
--add-registry-cert       | Manually installs container registry certificate
--set-sysprep             | Sets the host to be template-ready and erases machine-id
```
For logs collection use: data/logs/logs.sh
```
cd data/logs/
chmod +x logs.sh
sudo ./logs.sh

# To get help with usage: ./logs.sh --help
```


## Authors and acknowledgment

- Scripts developed by ISG Edge TME / NativeEdge team

Copyright (c) 2025 Dell Inc. or its subsidiaries. All Rights Reserved.
This software contains the intellectual property of Dell Inc. or is licensed to Dell Inc. from third parties.
Use of this software and the intellectual property contained therein is expressly limited to the terms and
conditions of the License Agreement under which it is provided by or on behalf of Dell Inc. or its subsidiaries.
